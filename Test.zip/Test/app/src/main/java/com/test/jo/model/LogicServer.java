package com.test.jo.model;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.recyclerview.widget.GridLayoutManager;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.test.jo.R;
import com.test.jo.databinding.ActivityBaseBinding;
import com.test.jo.tool.Activity;
import com.test.jo.tool.BypassAdapter;
import com.test.jo.tool.DataBypass;
import com.test.jo.tool.DataControl;
import com.test.jo.tool.DialogLoading;
import com.test.jo.tool.Preference;
import com.test.jo.tool.Tools;
import com.test.jo.tool.Value;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class LogicServer {

    private final Context context;
    private final DialogLoading dialogLoading;
    private final ActivityBaseBinding binding;
    //--
    private String addDeyPrivate;
    private String datePrivate;
    private String keyPrivate;
    private String nameDevicePrivate;
    private String uuidDevicePrivate;
    private String dateCreated;
    private boolean serverMode;
    private boolean memoryMode;
    private String versionApp;
    private String versionSock;
    private String newsHack;
    private String keyPrivateCpp = "0";
    private String keyPublicCpp = "0";
    private String bypassName;
    private int bypassMode;
    private String bypassTextFiles;
    private String bypassUuid;

    public LogicServer(Context context, DialogLoading dialogLoading, ActivityBaseBinding binding) {
        this.context = context;
        this.dialogLoading = dialogLoading;
        this.binding = binding;
    }

    //====================================================
    //--=====Logic Open app===============================
    //====================================================
    public void LogicOpenApp(String key) {
        dialogLoading.show();
        FirebaseFirestore.getInstance().collection(Value.COLLECTION_BASE).whereEqualTo(Value.BASE_ID, Tools.Dec(Tools.Rights(DataControl.ID_BASE.ordinal()))).whereEqualTo(Value.BASE_KEY_PRIVATE_CPP, Tools.Dec(Tools.Rights(DataControl.KEY_PRIVATE_CPP.ordinal()))).whereEqualTo(Value.BASE_KEY_PUBLIC_CPP, Tools.Dec(Tools.Rights(DataControl.KEY_PUBLIC_CPP.ordinal()))).get().addOnCompleteListener(taskBase -> {
            if (taskBase.isSuccessful() && !taskBase.getResult().isEmpty()) {
                for (QueryDocumentSnapshot data : taskBase.getResult()) {
                    serverMode = Boolean.TRUE.equals(data.getBoolean(Value.BASE_SERVER_MODE));
                    if (serverMode) {
                        versionApp = data.getString(Value.BASE_VERSION_APP);
                        assert versionApp != null;
                        if (versionApp.equals(Tools.GetVersion(context))) {
                            if (key != null && key.trim().length() == 20) {
                                LoginPrivate();
                                keyPrivate = key;
                            } else {
                                dialogLoading.cancel();
                                Activity.VisibleLogin(context, binding);
                                keyPrivate = null;
                            }
                        } else {
                            Toast.makeText(context, R.string.TEXT_UPDATE_APP, Toast.LENGTH_SHORT).show();
                            Tools.GoToURL(context, Tools.Dec(Tools.Rights(DataControl.TELEGRAM.ordinal())));
                            dialogLoading.cancel();
                        }
                    } else {
                        Toast.makeText(context, R.string.TEXT_OFF_SERVER, Toast.LENGTH_SHORT).show();
                        dialogLoading.cancel();
                    }
                }
            } else {
                if (taskBase.getException() != null)
                    Toast.makeText(context, "" + taskBase.getException(), Toast.LENGTH_SHORT).show();
                else Toast.makeText(context, R.string.TEXT_ERROR_SERVER, Toast.LENGTH_SHORT).show();
                dialogLoading.cancel();
            }
        });
    }
    //--======================

    //====================================================
    //--=====Logic Login Private==========================
    //====================================================
    private void LoginPrivate() {
        FirebaseFirestore.getInstance().collection(Value.COLLECTION_BASE).whereEqualTo(Value.BASE_ID, Tools.Dec(Tools.Rights(DataControl.ID_BASE.ordinal()))).whereEqualTo(Value.BASE_KEY_PRIVATE_CPP, Tools.Dec(Tools.Rights(DataControl.KEY_PRIVATE_CPP.ordinal()))).whereEqualTo(Value.BASE_KEY_PUBLIC_CPP, Tools.Dec(Tools.Rights(DataControl.KEY_PUBLIC_CPP.ordinal()))).get().addOnCompleteListener(taskBase -> {
            if (taskBase.isSuccessful() && !taskBase.getResult().isEmpty()) {
                for (QueryDocumentSnapshot data : taskBase.getResult()) {
                    serverMode = Boolean.TRUE.equals(data.getBoolean(Value.BASE_SERVER_MODE));
                    memoryMode = Boolean.TRUE.equals(data.getBoolean(Value.BASE_MEMORY_MODE));
                    versionApp = data.getString(Value.BASE_VERSION_APP);
                    versionSock = data.getString(Value.BASE_VERSION_SOCK);
                    keyPrivateCpp = data.getString(Value.BASE_KEY_PRIVATE_CPP);
                    keyPublicCpp = data.getString(Value.BASE_KEY_PUBLIC_CPP);
                    newsHack = data.getString(Value.BASE_NEWS_HACK);
                }
                Tools.SetDataServer(memoryMode, Float.parseFloat(versionApp));
                UserPrivate();
                LoadingBypass();
            } else {
                if (taskBase.getException() != null)
                    Toast.makeText(context, "" + taskBase.getException(), Toast.LENGTH_SHORT).show();
                else Toast.makeText(context, R.string.TEXT_ERROR_SERVER, Toast.LENGTH_SHORT).show();
                dialogLoading.cancel();
            }
        });
    }

    //====================================================
    //--=====Loading Bypass=================================
    //====================================================
    @SuppressLint("SetTextI18n")
    private void LoadingBypass() {
        ArrayList<DataBypass> dataBypassArrayList = new ArrayList<>();

        FirebaseFirestore.getInstance().collection(Value.COLLECTION_BYPASS).get().addOnCompleteListener(taskVip -> {
            if (taskVip.isSuccessful() && !taskVip.getResult().isEmpty()) {
                int i = 0;
                for (QueryDocumentSnapshot data : taskVip.getResult()) {
                    DocumentSnapshot snapshot = taskVip.getResult().getDocuments().get(i); //-- Get ID Documents
                    String Id = snapshot.getId(); //-- ID
                    i++;
                    Log.d("TAG", "LoadingBypass: " + Id);
                    bypassName = data.getString(Value.BYPASS_NAME);
                    bypassTextFiles = data.getString(Value.BYPASS_TEXT_FILES);
                    bypassMode = Integer.parseInt(Objects.requireNonNull(data.getString(Value.BYPASS_MODE)));
                    bypassUuid = Id;
                    int img;
                    if (bypassMode == 0) img = R.drawable.ic_risk;
                    else if (bypassMode == 1) img = R.drawable.ic_safe;
                    else img = R.drawable.ic_button;

                    dataBypassArrayList.add(new DataBypass(bypassName, bypassTextFiles, bypassUuid, img));
                }

                BypassAdapter adapter = new BypassAdapter(context, dataBypassArrayList, dialogLoading);
                binding.MainRvAdapterBypass.setAdapter(adapter);
                binding.MainRvAdapterBypass.setLayoutManager(new GridLayoutManager(context, 2));
                binding.MainRvAdapterBypass.setHasFixedSize(true);

            } else {
                dialogLoading.cancel();
                if (taskVip.getException() != null)
                    Toast.makeText(context, "" + taskVip.getException(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    //--======================

    //====================================================
    //--=====User Private=================================
    //====================================================
    @SuppressLint("SetTextI18n")
    private void UserPrivate() {
        FirebaseFirestore.getInstance().collection(Value.COLLECTION_VIP).whereEqualTo(Value.VIP_KEY_PRIVATE, keyPrivate).whereEqualTo(Value.VIP_KEY_PRIVATE_CPP, Tools.Dec(Tools.Rights(DataControl.KEY_PRIVATE_CPP.ordinal()))).get().addOnCompleteListener(taskVip -> {
            if (taskVip.isSuccessful() && !taskVip.getResult().isEmpty()) {
                DocumentSnapshot snapshot = taskVip.getResult().getDocuments().get(0); //-- Get ID Documents
                String Id = snapshot.getId(); //-- ID
                for (QueryDocumentSnapshot data : taskVip.getResult()) {
                    addDeyPrivate = data.getString(Value.VIP_ADD_DAY);
                    datePrivate = data.getString(Value.VIP_DATE_PRIVATE);
                    keyPrivate = data.getString(Value.VIP_KEY_PRIVATE);
                    nameDevicePrivate = data.getString(Value.VIP_NAME_DEVICE);
                    uuidDevicePrivate = data.getString(Value.VIP_UUID);
                    dateCreated = data.getString(Value.VIP_DATE_CREATED);
                }

                if (datePrivate.equals(Tools.Dec(Tools.Rights(DataControl._NULL.ordinal()))) && uuidDevicePrivate.equals(Tools.Dec(Tools.Rights(DataControl._NULL.ordinal()))) && nameDevicePrivate.equals(Tools.Dec(Tools.Rights(DataControl._NULL.ordinal()))) || uuidDevicePrivate.equals(Tools.Dec(Tools.Rights(DataControl._NULL.ordinal()))) && nameDevicePrivate.equals(Tools.Dec(Tools.Rights(DataControl._NULL.ordinal())))) {
                    Update(Id, addDeyPrivate);
                } else {
                    if (Tools.DateToNumber(Tools.MillisToDate()) < Tools.DateToNumber(datePrivate) && keyPrivateCpp.equals(Tools.Dec(Tools.Rights(DataControl.KEY_PRIVATE_CPP.ordinal()))) && keyPublicCpp.equals(Tools.Dec(Tools.Rights(DataControl.KEY_PUBLIC_CPP.ordinal()))) && Tools.CheckKeyCPP(Long.parseLong(keyPrivateCpp), Long.parseLong(keyPublicCpp)) && Tools.CheckVip() && Tools.CheckVersionApp() == Float.parseFloat(Tools.GetVersion(context))) {
                        if (uuidDevicePrivate.trim().equals(Tools.GetUuidDevice(context))) {
                            SetViewValue();
                            Activity.VisibleMain(context, binding);
                            Toast.makeText(context, R.string.TEXT_IS_SUCCESSFUL, Toast.LENGTH_SHORT).show();
                            Preference.setValue(context, Value.SAVE_KEY_LOGIN, keyPrivate);
                            dialogLoading.cancel();
                            if (!Tools.CheckMemory())
                                binding.MainLayBypass.setVisibility(View.INVISIBLE);
                            DownloadFiles();
                        } else {
                            Preference.setValue(context, Value.SAVE_KEY_LOGIN, null);
                            Activity.VisibleLogin(context, binding);
                            dialogLoading.cancel();
                            Toast.makeText(context, R.string.TEXT_USED_KEY, Toast.LENGTH_SHORT).show();
                        }
                    } else Delete(Id);
                }
            } else {
                dialogLoading.cancel();
                if (taskVip.getException() != null)
                    Toast.makeText(context, "" + taskVip.getException(), Toast.LENGTH_SHORT).show();
                else {
                    Preference.setValue(context, Value.SAVE_IS_LOGIN, Tools.SecurityBool(Value.BOOL_F));
                    Preference.setValue(context, Value.SAVE_KEY_LOGIN, null);
                    Activity.VisibleLogin(context, binding);
                    Toast.makeText(context, R.string.TEXT_NOT_FUNDE, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    //--======================

    public void Delete(String id) {
        FirebaseFirestore.getInstance().collection(Value.COLLECTION_VIP).document(id).delete().addOnSuccessListener(unused -> {
            Preference.setValue(context, Value.SAVE_KEY_LOGIN, null);
            Activity.VisibleLogin(context, binding);
            dialogLoading.cancel();
            Toast.makeText(context, R.string.TEXT_EXPIRATION, Toast.LENGTH_SHORT).show();
        }).addOnFailureListener(unused -> {
            UserPrivate();
            Toast.makeText(context, "" + unused, Toast.LENGTH_SHORT).show();
        });
    }

    public void Update(String id, String addDay) {
        Map<String, Object> Data = new HashMap<>();
        Data.put(Value.VIP_UUID, Tools.GetUuidDevice(context));
        Data.put(Value.VIP_NAME_DEVICE, Tools.GetNameDevices());
        Data.put(Value.VIP_DATE_PRIVATE, Tools.AddHour(Tools.MillisToDate(), Integer.parseInt(addDay)));
        if (dateCreated.equals(Tools.Dec(Tools.Rights(DataControl._NULL.ordinal()))))
            Data.put(Value.VIP_DATE_CREATED, Tools.MillisToDate());
        FirebaseFirestore.getInstance().collection(Value.COLLECTION_VIP).document(id).update(Data).addOnSuccessListener(unused -> UserPrivate()).addOnFailureListener(unused -> {
            Preference.setValue(context, Value.SAVE_KEY_LOGIN, null);
            Activity.VisibleLogin(context, binding);
            dialogLoading.cancel();
            Toast.makeText(context, "" + unused, Toast.LENGTH_SHORT).show();
        });
    }

    //====================================================
    //--=====Logic Download Files=========================
    //====================================================
    private void DownloadFiles() {
        File matrix64 = new File(Tools.Dec(Tools.Rights(DataControl.PATH.ordinal())), Value.FILES_MATRIX_64);
        File matrix32 = new File(Tools.Dec(Tools.Rights(DataControl.PATH.ordinal())), Value.FILES_MATRIX_32);

        if (!matrix64.exists() || !matrix32.exists()) {
            if (Tools.CheckKeyCPP(Long.parseLong(keyPrivateCpp), Long.parseLong(keyPublicCpp))) {
                DownloadFiles(matrix64, matrix32);
            }
        } else {
            if (!Preference.getValueString(context, Value.BASE_VERSION_SOCK).equals(versionSock)) {
                if (Tools.CheckKeyCPP(Long.parseLong(keyPrivateCpp), Long.parseLong(keyPublicCpp))) {
                    DownloadFiles(matrix64, matrix32);
                }
            }
        }
    }

    private void DownloadFiles(File matrix64, File matrix32) {
        dialogLoading.show();
        FirebaseStorage.getInstance().getReference().child("sockTest/" + Value.FILES_MATRIX_64).getFile(matrix64).addOnSuccessListener(taskSnapshot -> Preference.setValue(context, Value.SAVE_APP_VERSION_SOCK, versionSock)).addOnFailureListener(e -> {
            dialogLoading.cancel();
            Toast.makeText(context, "" + e, Toast.LENGTH_SHORT).show();
        });

        FirebaseStorage.getInstance().getReference().child("sockTest/" + Value.FILES_MATRIX_32).getFile(matrix32).addOnSuccessListener(taskSnapshot -> {
            dialogLoading.cancel();
            Tools.Permission(context);
        }).addOnFailureListener(e -> {
            dialogLoading.cancel();
            Tools.Permission(context);
            Toast.makeText(context, "" + e, Toast.LENGTH_SHORT).show();
        });

    }
    //--======================

    //====================================================
    //--=====Set View Value=========================
    //====================================================
    @SuppressLint("SetTextI18n")
    private void SetViewValue() {
        dialogLoading.show();
        binding.MainTvKey.setText("" + keyPrivate);
        StringBuilder expirationDateKey = new StringBuilder();
        expirationDateKey.append(Tools.FormatDateToString(datePrivate)).append(" - ");
        expirationDateKey.append("day: ");
        expirationDateKey.append(Tools.FormatDateToDey(Tools.DifferenceTwoDates(Tools.MillisToDate(), datePrivate)));
        expirationDateKey.append("  hour: ");
        expirationDateKey.append(Tools.FormatDateToHour(Tools.DifferenceTwoDates(Tools.MillisToDate(), datePrivate)));
        binding.MainTvExpirationDateKey.setText(expirationDateKey);
        binding.MainTvModeKey.setText(R.string.TEXT_YOU_VIP);
        binding.MainTvInfoVersionApp.setText(versionApp);
        binding.MainTvInfoVersionFiles.setText(versionSock);
        binding.SettingTvNameDevice.setText(nameDevicePrivate);
        binding.SettingTvUuidDevice.setText(uuidDevicePrivate);
        String[] newsSplit = newsHack.split("%%%");
        StringBuilder newsFormats = new StringBuilder();
        for (String s : newsSplit) {
            newsFormats.append(s);
            newsFormats.append("\n\n");
        }
        binding.NewsTvNewsHack.setText(newsFormats);
    }

}