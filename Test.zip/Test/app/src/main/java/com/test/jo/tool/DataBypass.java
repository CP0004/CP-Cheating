package com.test.jo.tool;

public class DataBypass {
    private String name;
    private String textFiles;
    private String uuid;
    private int mode;

    public DataBypass(String name, String textFiles, String uuid, int mode) {
        this.name = name;
        this.textFiles = textFiles;
        this.uuid = uuid;
        this.mode = mode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTextFiles() {
        return textFiles;
    }

    public void setTextFiles(String textFiles) {
        this.textFiles = textFiles;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }
}

