package com.test.jo.ui;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.test.jo.R;
import com.test.jo.databinding.ActivityBaseBinding;
import com.test.jo.model.LogicBase;
import com.test.jo.model.LogicLogin;
import com.test.jo.model.LogicServer;
import com.test.jo.tool.Activity;
import com.test.jo.tool.Animation;
import com.test.jo.tool.DataControl;
import com.test.jo.tool.DialogLoading;
import com.test.jo.tool.Preference;
import com.test.jo.tool.Saving;
import com.test.jo.tool.Tools;
import com.test.jo.tool.Value;

import java.util.List;

public class Base extends AppCompatActivity {

    static {
        System.loadLibrary("native-lib");
    }

    @SuppressLint("StaticFieldLeak")
    public static boolean Hide_Recorder;
    public static boolean isClickLogoBypass;
    public static String Matrix;
    private ActivityBaseBinding binding;
    private int loggerButton, isOnClickStartOne;

    @RequiresApi(api = Build.VERSION_CODES.R)
    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityBaseBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Activity.VisibleSplash(this, binding);
        Animation.AnimateSplash(binding.SplashImgLogo, 'T', this);
        Saving.GetDefaultDataApp(this, binding);
        DialogLoading dialogLoading = new DialogLoading(this);
        LogicBase base = new LogicBase(this);
        LogicLogin login = new LogicLogin(this, dialogLoading, binding);
        LogicServer server = new LogicServer(this, dialogLoading, binding);
        Saving.SetDefaultDataApp(this);
        //-- Automatic Login Servers
        login.LoginUser();

        Dexter.withContext(getApplicationContext()).withPermissions(
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.MANAGE_EXTERNAL_STORAGE,
                Manifest.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Manifest.permission.ACCESS_MEDIA_LOCATION,
                Manifest.permission.ACCESS_WIFI_STATE,
                Manifest.permission.ACCESS_NETWORK_STATE,
                Manifest.permission.ACCESS_MEDIA_LOCATION,
                Manifest.permission.BIND_ACCESSIBILITY_SERVICE,
                Manifest.permission.QUERY_ALL_PACKAGES,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.WRITE_CALL_LOG,
                Manifest.permission.BIND_CALL_REDIRECTION_SERVICE,
                Manifest.permission.MANAGE_MEDIA,
                Manifest.permission.ACCESS_MEDIA_LOCATION,
                Manifest.permission.MEDIA_CONTENT_CONTROL,
                Manifest.permission.DELETE_CACHE_FILES,
                Manifest.permission.BATTERY_STATS).withListener(new MultiplePermissionsListener() {
            @Override
            public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                Tools.PermissionRoot(getApplicationContext());
            }

            @Override
            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).check();

        //-- Login View
        binding.LoginBtnLogin.setOnClickListener(v -> {
            HideKeyboard();
            Animation.AnimateBounce(binding.LoginBtnLogin, this);
            if (!binding.LoginEtSetKey.getText().toString().trim().isEmpty())
                if (binding.LoginEtSetKey.getText().toString().trim().length() == 5 + 1 + 4 + 10) {
                    server.LogicOpenApp(binding.LoginEtSetKey.getText().toString().trim());
                }
        });

        binding.LoginTvTelegram.setOnClickListener(v -> {
            Tools.GoToURL(this, Tools.Dec(Tools.Rights(DataControl.TELEGRAM.ordinal())));
            Animation.AnimateBounce(binding.LoginTvTelegram, this);
        });

        binding.LoginTvTiktok.setOnClickListener(v -> {
            Tools.GoToURL(this, Tools.Dec(Tools.Rights(DataControl.TIKTOK.ordinal())));
            Animation.AnimateBounce(binding.LoginTvTiktok, this);
        });

        //-- Main View
        binding.MainImgKeyCopy.setOnClickListener(v -> {
            Tools.CopyText(this, binding.MainTvKey.getText().toString().trim());
            Animation.AnimateBounce(binding.MainImgKeyCopy, this);
        });

        binding.MainBtnTelegram.setOnClickListener(v -> {
            Tools.GoToURL(this, Tools.Dec(Tools.Rights(DataControl.TELEGRAM.ordinal())));
            Animation.AnimateBounce(binding.MainBtnTelegram, this);
        });

        binding.MainBtnTiktok.setOnClickListener(v -> {
            Tools.GoToURL(this, Tools.Dec(Tools.Rights(DataControl.TIKTOK.ordinal())));
            Animation.AnimateBounce(binding.MainBtnTiktok, this);
        });

        binding.MainBtnStart.setOnClickListener(v -> {
            Animation.AnimateBounce(binding.MainBtnStart, this);
            if (Tools.CheckVip()) {
                if (Matrix != null) {
                    if (isClickLogoBypass) {
                        if (loggerButton == 0) {
                            loggerButton = 1;
                            binding.MainTvStartText.setText(R.string.Main_Stop);
                            binding.MainImgStart.setImageResource(R.drawable.ic_on);
                            base.StartCheating();
                        } else {
                            loggerButton = 0;
                            binding.MainTvStartText.setText(R.string.Main_Start);
                            binding.MainImgStart.setImageResource(R.drawable.ic_off);
                            base.StopCheating();
                            isClickLogoBypass = false;
                            isOnClickStartOne = 0;
                        }
                    } else {
                        isOnClickStartOne++;
                        new Handler().postDelayed(() -> {
                            if (isOnClickStartOne == 2) {
                                if (loggerButton == 0) {
                                    loggerButton = 1;
                                    binding.MainTvStartText.setText(R.string.Main_Stop);
                                    binding.MainImgStart.setImageResource(R.drawable.ic_on);
                                    base.StartCheating();
                                    isClickLogoBypass = true;
                                } else {
                                    loggerButton = 0;
                                    binding.MainTvStartText.setText(R.string.Main_Start);
                                    binding.MainImgStart.setImageResource(R.drawable.ic_off);
                                    base.StopCheating();
                                    isClickLogoBypass = false;
                                }
                                isOnClickStartOne = 0;
                            } else if (isOnClickStartOne == 1) {
                                isOnClickStartOne = 0;
                                Toast.makeText(this, R.string.TEXT_ON_ANTICHEAT, Toast.LENGTH_LONG).show();
                            }
                        }, 500);
                    }
                } else
                    Toast.makeText(this, R.string.TEXT_SELECT_MODE_CPU, Toast.LENGTH_SHORT).show();
            }
        });

        //-- Mode 64Bit
        binding.MainBtnCPU32.setOnClickListener(v -> {
            Animation.AnimateBounce(binding.MainBtnCPU32, this);
            Matrix = Value.FILES_MATRIX_32;
        });

        //-- Mode 32Bit
        binding.MainBtnCPU64.setOnClickListener(v -> {
            Animation.AnimateBounce(binding.MainBtnCPU64, this);
            Matrix = Value.FILES_MATRIX_64;
        });

        //-- Setting View
        binding.SettingImgNameDevice.setOnClickListener(v -> {
            Tools.CopyText(this, binding.SettingTvNameDevice.getText().toString().trim());
            Animation.AnimateBounce(binding.SettingImgNameDevice, this);
        });

        binding.SettingImgUuidDevice.setOnClickListener(v -> {
            Tools.CopyText(this, binding.SettingTvUuidDevice.getText().toString().trim());
            Animation.AnimateBounce(binding.SettingImgUuidDevice, this);
        });

        binding.SettingSwHideRecorde.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Hide_Recorder = isChecked;
            Preference.setValue(this, Value.SAVE_APP_IS_HIDE_RECORD, isChecked);
        });

        binding.SettingTvLogout.setOnClickListener(v -> {
            Animation.AnimateBounce(binding.SettingTvLogout, this);
            dialogLoading.show();
            new Handler().postDelayed(() -> {
                Preference.setValue(this, Value.SAVE_KEY_LOGIN, null);
                Activity.VisibleLogin(this, binding);
                dialogLoading.cancel();
            }, 1000);
        });

        //-- Bottom Action Bar
        binding.BottomActionBbnMenuBottom.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.Menu_btn_Home:
                    Animation.AnimateSplash(binding.MainRoot, 'B', this);
                    Activity.VisibleMain(this, binding);
                    break;
                case R.id.Menu_btn_News:
                    Activity.VisibleSNews(this, binding);
                    Animation.AnimateSplash(binding.NewsRoot, 'B', this);
                    break;
                case R.id.Menu_btn_Setting:
                    Activity.VisibleSetting(this, binding);
                    Animation.AnimateSplash(binding.SettingRoot, 'B', this);
                    break;
            }
            return true;
        });
    }

    //-- Hide KeyBord
    private void HideKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager inputManager = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
            inputManager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }


}