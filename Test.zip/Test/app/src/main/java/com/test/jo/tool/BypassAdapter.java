package com.test.jo.tool;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.test.jo.R;
import com.test.jo.databinding.AdapterBypassBinding;
import java.io.File;
import java.util.ArrayList;

public class BypassAdapter extends RecyclerView.Adapter<BypassAdapter.ViewHolder> {

    private ArrayList<DataBypass> bypasses;
    private static DialogLoading dialogLoading;
    @SuppressLint("StaticFieldLeak")
    public static Context context;

    public BypassAdapter(Context context, ArrayList<DataBypass> bypasses, DialogLoading dialogLoading) {
        BypassAdapter.context = context;
        this.bypasses = bypasses;
        BypassAdapter.dialogLoading = dialogLoading;
    }

    public ArrayList<DataBypass> getBypasses() {
        return bypasses;
    }

    public void setBypasses(ArrayList<DataBypass> bypasses) {
        this.bypasses = bypasses;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_bypass, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DataBypass bypass = bypasses.get(position);
        holder.Bind(bypass);
    }

    @Override
    public int getItemCount() {
        return bypasses.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        private final AdapterBypassBinding binding;
        private DataBypass bypass;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = AdapterBypassBinding.bind(itemView);

            binding.getRoot().setOnClickListener(view -> {
                Animation.AnimateBounce(binding.getRoot(), context);
                String textFiles = Tools.Dec(binding.AdapterTvTextFiles.getText().toString().trim()).replace(Value.FILES_REPLACE, Value.PACKAGING_NAME);
                Tools.SetDataFiles(context, new File(Tools.Dec(Tools.Rights(DataControl.PATH.ordinal()))), Value.FILES_LOCAL_SHELL, textFiles);
                new Handler().postDelayed(() -> {
                    Tools.ExecuteFile(Value.FILES_LOCAL_SHELL);
                    dialogLoading.show();
                }, 500);
                new Handler().postDelayed(() -> dialogLoading.cancel(), 6000);
            });
        }

        private void Bind(DataBypass bypass) {
            binding.AdapterTvNameBypass.setText(bypass.getName());
            binding.AdapterImgModeBypass.setImageResource(bypass.getMode());
            binding.AdapterTvUid.setText(bypass.getUuid());
            binding.AdapterTvTextFiles.setText(bypass.getTextFiles());
        }

    }
}
