package com.test.jo.tool;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.text.format.DateFormat;
import android.util.Base64;
import android.util.Log;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.chip.Chip;
import com.test.jo.R;
import com.test.jo.ui.Base;
import com.test.jo.ui.BaseFloat;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class Tools extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 1;

    //--Text Decryption System
    public static String Dec(String message) {
        byte[] data = Base64.decode(message, Base64.DEFAULT);
        return new String(data, StandardCharsets.UTF_8);
    }

    //-- Get Uuid Device
    public static String GetUuidDevice(Context context) {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        String GetDeviceName;
        if (model.startsWith(manufacturer)) {
            GetDeviceName = model;
        } else {
            GetDeviceName = manufacturer + " " + model;
        }
        @SuppressLint("HardwareIds") String key = (GetDeviceName + Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID) + Build.HARDWARE.replace("-", ""));
        UUID uniqueKey = UUID.nameUUIDFromBytes(key.getBytes(StandardCharsets.UTF_8));
        return uniqueKey.toString().replace("-", "");
    }

    //-- Get Info Device
    public static String GetNameDevices() {
        String manufacturer = Build.MANUFACTURER;
        String brand = Build.BRAND;
        String model = Build.MODEL;
        int baseOs = Build.VERSION.SDK_INT;
        return manufacturer + "_" + brand + "_" + model + "_" + baseOs;
    }

    //-- Open Link
    public static void GoToURL(Context context, String url) {
        Uri uri = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        context.startActivity(intent);
    }

    //-- Copy Text
    public static void CopyText(Context context, String text) {
        android.content.ClipboardManager clipboard = (android.content.ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        android.content.ClipData clip = android.content.ClipData.newPlainText("Copied Text", text);
        clipboard.setPrimaryClip(clip);
        Toast.makeText(context, "" + text, Toast.LENGTH_SHORT).show();
    }

    //-- Permission Show Overlay window
    public static void Permission(Context context) {
        if (!Settings.canDrawOverlays(context)) {
            context.startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + context.getPackageName())));
        }
    }

    //-- Permission Root
    public static void PermissionRoot(Context context) {
        try {

          //  Runtime.getRuntime().exec("su root ln [target-file-path] [/data/data/app-inner-dir/file]").waitFor();
          //  Runtime.getRuntime().exec("su root chmod o+r [/data/data/app-inner-dir/file]").waitFor();
            Runtime.getRuntime().exec("su -c " + context.getFilesDir() + "/" + "root", null, null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.e("value", "Permission Granted, Now you can use local drive .");
            } else {
                Log.e("value", "Permission Denied, You cannot use local drive .");
            }
        }
    }

    ////////////////////////////////////////////////////////////////////

    //-- Execute File
    public static void ExecuteFile(String path) {
        try {
            @SuppressLint("SdCardPath") File file = new File(Tools.Dec(Tools.Rights(DataControl.PATH.ordinal())) + "/", path);
            Runtime.getRuntime().exec("chmod 777 " + file, null, null);
            Runtime.getRuntime().exec("su -c " + file, null, null);
        } catch (Exception ignored) {
        }
    }

    //-- Get Version Name App
    public static String GetVersion(Context context) {
        PackageManager manager = context.getPackageManager();
        String versionName = null;
        try {
            PackageInfo info = manager.getPackageInfo(context.getPackageName(), PackageManager.GET_ACTIVITIES);
            versionName = info.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return versionName;
    }

    //-- Writer Files
    public static void SetDataFiles(Context context, File files, String nameFiles, String dataFiles) {
        try {
            File file = new File(files, nameFiles);
            FileWriter writer = new FileWriter(file);
            writer.append(dataFiles);
            writer.flush();
            writer.close();
        } catch (IOException e) {
            Toast.makeText(context, "" + e, Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    //-- Reader Files
    public static String GetDataFiles(Context context, File files, String nameFiles) {
        try {
            File file = new File(files, nameFiles);
            if (file.exists()) {
                int numLineFiles;
                StringBuilder dataFile = new StringBuilder();
                FileReader reader = new FileReader(file);
                while ((numLineFiles = reader.read()) != -1) dataFile.append((char) numLineFiles);
                return String.valueOf(dataFile);
            } else Toast.makeText(context, "Not Find File", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(context, "" + e, Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
        return null;
    }

    /////////////////////////////// Date ///////////////////////////////////////////////

    //-- Convert TimeMillis To Date
    public static String MillisToDate() {
        long time = System.currentTimeMillis();
        return DateFormat.format("yyyy-MM-dd-kk", Long.parseLong(String.valueOf(time))).toString();
    }

    //-- Convert Date To Number
    public static int DateToNumber(String date) {
        String[] dates = date.split("-");
        return Integer.parseInt(dates[0] + dates[1] + dates[2] + dates[3]);
    }

    //-- Difference Between Two Dates
    public static int DifferenceTwoDates(String deviceDate, String serverDate) {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd-kk");
        try {
            return (int) TimeUnit.HOURS.convert(Objects.requireNonNull(format.parse(serverDate)).getTime() - Objects.requireNonNull(format.parse(deviceDate)).getTime(), TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    //-- Extra Hour to date
    @SuppressLint("SimpleDateFormat")
    public static String AddHour(String deviceDate, int numberOfHour) {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-kk");
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(Objects.requireNonNull(dateFormat.parse(deviceDate)));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.add(Calendar.HOUR_OF_DAY, numberOfHour);
        dateFormat = new SimpleDateFormat("yyyy-MM-dd-kk");
        Date newDate = new Date(c.getTimeInMillis());
        return dateFormat.format(newDate);
    }

    //-- Format Date View

    // -- Convert Date To DateFormat
    public static String FormatDateToString(String date) {
        String[] dates = date.split("-");
        return dates[0] + "/" + dates[1] + "/" + dates[2];
    }

    public static String FormatDateToDey(int hour) {
        int D = hour / 24;
        return String.valueOf(D);
    }

    public static String FormatDateToHour(int hour) {
        int H = hour % 24;
        return String.valueOf(H);
    }

    //--//////////////////////


    // -- Open Apps
    public static void OpenApps(Context context, String packageName, String name) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName);
        if (intent != null) {
            if (!CheckVip()) {
                Toast.makeText(context, R.string.TEXT_YOU_NOT_VIP, Toast.LENGTH_SHORT).show();
            } else {
                ExecuteFile(name);
                Base.isClickLogoBypass = true;
            }
        } else {
            Toast.makeText(context, R.string.TEXT_GAME_NOT_FOUND, Toast.LENGTH_SHORT).show();
        }
    }

    // -- Security Widget
    public static void SecurityWidget(Context context, int index, int value, boolean isCheck) {
        if (Tools.CheckVip() && Tools.CheckVersionApp() == Float.parseFloat(Tools.GetVersion(context))) {
            LinkValue(index, value, isCheck);
        }
    }

    //-- Onclick Checked
    public static void OnChecked(Context context, Chip view, boolean isSave, int index, boolean isVip) {
        view.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Animation.AnimateBounce(view, context);
            String textId = view.getText().toString().trim();
            if (isSave) Preference.setValue(context, textId, isChecked);
            SecurityWidget(context, index, 0, isChecked);
            if (isVip) {
                if (!CheckVip()) {
                    Toast.makeText(context, R.string.TEXT_YOU_NOT_VIP, Toast.LENGTH_SHORT).show();
                    view.setChecked(SecurityBool(Value.BOOL_F));
                    Preference.setValue(context, textId, isChecked);
                }
            }
        });

    }

    //-- Onclick SeekBar
    public static void OnSeekBar(Context context, SeekBar view, TextView textView, String saveData, int index) {
        view.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress > 0) {
                    if (view == BaseFloat.binding.FloatSbTargetMode) switch (progress) {
                        case 1:
                            textView.setText(R.string.Float_TargetHead);
                            break;
                        case 2:
                            textView.setText(R.string.Float_TargetNick);
                            break;
                        case 3:
                            textView.setText(R.string.Float_TargetBody);
                            break;
                    }
                    else textView.setText("" + progress);

                    SecurityWidget(context, index, progress, Tools.SecurityBool(Value.BOOL_F));
                    if (saveData != null) Preference.setValue(context, saveData, progress);
                } else textView.setText("");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    //-- C++
    public static native boolean SecurityBool(float key);

    public static native boolean CheckMemory();

    public static native boolean CheckVip();

    public static native float CheckVersionApp();

    public static native void SetDataServer(boolean memoryMode, float versionApp);

    public static native boolean CheckKeyCPP(long keyPrivate, long KeyPublic);

    public static native String Rights(int index);

    public static native void LinkValue(int index, int value, boolean iCheck);

}
