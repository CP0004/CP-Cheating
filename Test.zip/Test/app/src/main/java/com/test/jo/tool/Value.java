package com.test.jo.tool;

public class Value {

    public static final String FILE_SAVE_APP = "Data";
    public static final String SAVE_IS_SET_APP_SAVING = "isSetDataApp";
    public static final String SAVE_IS_LOGIN = "isLogin";
    public static final String SAVE_KEY_LOGIN = "KeyLogin";
    public static final String SAVE_APP_VERSION_SOCK = "VersionSock";
    public static final String SAVE_APP_IS_GET_DATA = "IsGetData";
    public static final String SAVE_APP_IS_HIDE_RECORD = "IsHideRecord";

    public static final String SAVE_APP_WIDTH_LINE = "widthLine";
    public static final String SAVE_APP_RADIUS_AFTER_360 = "radiusAfter360";
    public static final String SAVE_APP_SIZE_ITEM = "sizeItem";
    public static final String SAVE_APP_SIZE_VEHICLE = "sizeVehicle";
    public static final String SAVE_APP_SIZE_INFO = "sizeInfo";
    public static final String SAVE_APP_UP_INFO = "upInfo";
    public static final String SAVE_APP_FOV_BULLET = "fovBullet";
    public static final String SAVE_APP_DIST_BULLET = "distBullet";
    public static final String SAVE_APP_TARGET_MODE = "TargetMode";

    public static final String COLLECTION_BASE = "BaseTest";
    public static final String COLLECTION_VIP = "UserPrivateTest";
    public static final String COLLECTION_BYPASS = "Bypass";

    public static final String BYPASS_NAME = "Name";
    public static final String BYPASS_MODE = "Mode";
    public static final String BYPASS_TEXT_FILES = "TextFiles";

    public static final String BASE_ID = "Id";
    public static final String BASE_KEY_PUBLIC_CPP = "KeyPublicCpp";
    public static final String BASE_KEY_PRIVATE_CPP = "KeyPrivateCpp";
    public static final String BASE_SERVER_MODE = "ServerMode";
    public static final String BASE_MEMORY_MODE = "MemoryMode";
    public static final String BASE_VERSION_APP = "VersionApp";
    public static final String BASE_VERSION_SOCK = "VersionSock";
    public static final String BASE_NEWS_HACK = "NewsHack";

    public static final String VIP_KEY_PRIVATE = "KeyPrivate";
    public static final String VIP_KEY_PRIVATE_CPP = "KeyPrivateCpp";
    public static final String VIP_DATE_PRIVATE = "DatePrivate";
    public static final String VIP_UUID = "Uuid";
    public static final String VIP_NAME_DEVICE = "NameDevice";
    public static final String VIP_ADD_DAY = "AddDey";
    public static final String VIP_DATE_CREATED = "DateCreated";

    //Other
    public static final float BOOL_T = 1.010f;
    public static final float BOOL_F = 0.0f;
    public static final String PACKAGING_NAME = "com.test.jo";

    public static final String FILES_MATRIX_64 = "Config_64.json";
    public static final String FILES_MATRIX_32 = "Config_32.json";
    public static final String FILES_REPLACE = "RANDOM_PACKAGING";
    public static final String FILES_LOCAL_SHELL = "ServerOn.sh";

}