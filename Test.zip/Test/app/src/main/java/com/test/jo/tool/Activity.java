package com.test.jo.tool;

import android.content.Context;
import android.view.View;

import com.test.jo.R;
import com.test.jo.databinding.ActivityBaseBinding;
import com.test.jo.databinding.WindowFloatingBinding;

public class Activity {

    //======================= ROOT ================================================================
    //-- Visible Main Activity
    public static void VisibleMain(Context context, ActivityBaseBinding binding) {
        binding.MainRoot.setVisibility(View.VISIBLE);
        binding.SplashRoot.setVisibility(View.GONE);
        binding.LoginRoot.setVisibility(View.GONE);
        binding.NewsRoot.setVisibility(View.GONE);
        binding.SettingRoot.setVisibility(View.GONE);
        binding.BottomActionBbnMenuBottom.setVisibility(View.VISIBLE);
    }

    //-- Visible News Activity
    public static void VisibleSNews(Context context, ActivityBaseBinding binding) {
        binding.MainRoot.setVisibility(View.GONE);
        binding.SplashRoot.setVisibility(View.GONE);
        binding.LoginRoot.setVisibility(View.GONE);
        binding.NewsRoot.setVisibility(View.VISIBLE);
        binding.SettingRoot.setVisibility(View.GONE);
        binding.BottomActionBbnMenuBottom.setVisibility(View.VISIBLE);
    }

    //-- Visible Setting Activity
    public static void VisibleSetting(Context context, ActivityBaseBinding binding) {
        binding.MainRoot.setVisibility(View.GONE);
        binding.SplashRoot.setVisibility(View.GONE);
        binding.LoginRoot.setVisibility(View.GONE);
        binding.NewsRoot.setVisibility(View.GONE);
        binding.SettingRoot.setVisibility(View.VISIBLE);
        binding.BottomActionBbnMenuBottom.setVisibility(View.VISIBLE);
    }

    //-- Visible Splash Activity
    public static void VisibleSplash(Context context, ActivityBaseBinding binding) {
        binding.MainRoot.setVisibility(View.GONE);
        binding.SplashRoot.setVisibility(View.VISIBLE);
        binding.LoginRoot.setVisibility(View.GONE);
        binding.NewsRoot.setVisibility(View.GONE);
        binding.SettingRoot.setVisibility(View.GONE);
        binding.BottomActionBbnMenuBottom.setVisibility(View.GONE);
    }

    //-- Visible Login Activity
    public static void VisibleLogin(Context context, ActivityBaseBinding binding) {
        binding.MainRoot.setVisibility(View.GONE);
        binding.SplashRoot.setVisibility(View.GONE);
        binding.LoginRoot.setVisibility(View.VISIBLE);
        binding.NewsRoot.setVisibility(View.GONE);
        binding.SettingRoot.setVisibility(View.GONE);
        binding.BottomActionBbnMenuBottom.setVisibility(View.GONE);
    }

    //======================= Float ROOT ================================================================
    //-- Visible Menu Float
    public static void VisibleFloatWindow(Context context, WindowFloatingBinding binding) {
        binding.FloatLayRoot.setVisibility(View.VISIBLE);
        binding.FloatImgRoot.setVisibility(View.GONE);
    }

    //-- Gone Menu Float
    public static void GoneFloatWindow(Context context, WindowFloatingBinding binding) {
        binding.FloatLayRoot.setVisibility(View.GONE);
        binding.FloatImgRoot.setVisibility(View.VISIBLE);
    }

    //======================= Layout Menu Float ================================================================
    //-- Visible Menu Layout Radar
    public static void VisibleLayoutRadar(Context context, WindowFloatingBinding binding) {
        Animation.AnimateBounce(binding.FloatTvRadar, context);
        Animation.AnimateSplash(binding.FloatLayRadar, 'T', context);
        binding.FloatLayRadar.setVisibility(View.VISIBLE);
        binding.FloatLayItems.setVisibility(View.GONE);
        binding.FloatLayMemory.setVisibility(View.GONE);
        binding.FloatLaySetting.setVisibility(View.GONE);
        binding.FloatBtnRadar.setBackgroundResource(R.drawable.list_select);
        binding.FloatBtnItem.setBackgroundResource(R.drawable.list_not_select);
        binding.FloatBtnMemory.setBackgroundResource(R.drawable.list_not_select);
        binding.FloatBtnSetting.setBackgroundResource(R.drawable.list_not_select);

    }

    //-- Visible Menu Layout Item
    public static void VisibleLayoutItems(Context context, WindowFloatingBinding binding) {
        Animation.AnimateBounce(binding.FloatTvItem, context);
        Animation.AnimateSplash(binding.FloatLayItems, 'T', context);
        binding.FloatLayRadar.setVisibility(View.GONE);
        binding.FloatLayItems.setVisibility(View.VISIBLE);
        binding.FloatLayMemory.setVisibility(View.GONE);
        binding.FloatLaySetting.setVisibility(View.GONE);
        binding.FloatBtnRadar.setBackgroundResource(R.drawable.list_not_select);
        binding.FloatBtnItem.setBackgroundResource(R.drawable.list_select);
        binding.FloatBtnMemory.setBackgroundResource(R.drawable.list_not_select);
        binding.FloatBtnSetting.setBackgroundResource(R.drawable.list_not_select);
    }

    //-- Visible Menu Layout Memory
    public static void VisibleLayoutMemory(Context context, WindowFloatingBinding binding) {
        Animation.AnimateBounce(binding.FloatTvMemory, context);
        Animation.AnimateSplash(binding.FloatLayMemory, 'T', context);
        binding.FloatLayRadar.setVisibility(View.GONE);
        binding.FloatLayItems.setVisibility(View.GONE);
        binding.FloatLayMemory.setVisibility(View.VISIBLE);
        binding.FloatLaySetting.setVisibility(View.GONE);
        binding.FloatBtnRadar.setBackgroundResource(R.drawable.list_not_select);
        binding.FloatBtnItem.setBackgroundResource(R.drawable.list_not_select);
        binding.FloatBtnMemory.setBackgroundResource(R.drawable.list_select);
        binding.FloatBtnSetting.setBackgroundResource(R.drawable.list_not_select);
    }

    //-- Visible Menu Layout Setting
    public static void VisibleLayoutSetting(Context context, WindowFloatingBinding binding) {
        Animation.AnimateBounce(binding.FloatTvSetting, context);
        Animation.AnimateSplash(binding.FloatLaySetting, 'T', context);
        binding.FloatLayRadar.setVisibility(View.GONE);
        binding.FloatLayItems.setVisibility(View.GONE);
        binding.FloatLayMemory.setVisibility(View.GONE);
        binding.FloatLaySetting.setVisibility(View.VISIBLE);
        binding.FloatBtnRadar.setBackgroundResource(R.drawable.list_not_select);
        binding.FloatBtnItem.setBackgroundResource(R.drawable.list_not_select);
        binding.FloatBtnMemory.setBackgroundResource(R.drawable.list_not_select);
        binding.FloatBtnSetting.setBackgroundResource(R.drawable.list_select);
    }

}