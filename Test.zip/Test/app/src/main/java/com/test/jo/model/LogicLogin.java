package com.test.jo.model;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

import com.test.jo.R;
import com.test.jo.databinding.ActivityBaseBinding;
import com.test.jo.tool.DataControl;
import com.test.jo.tool.DialogLoading;
import com.test.jo.tool.Preference;
import com.test.jo.tool.Tools;
import com.google.firebase.auth.FirebaseAuth;
import com.test.jo.tool.Value;

public class LogicLogin {

    private final Context context;
    private final DialogLoading dialogLoading;
    private final ActivityBaseBinding binding;

    public LogicLogin(Context context, DialogLoading dialogLoading, ActivityBaseBinding binding) {
        this.context = context;
        this.dialogLoading = dialogLoading;
        this.binding = binding;
    }

    public void LoginUser() {
        FirebaseAuth.getInstance().signInWithEmailAndPassword(Tools.Dec(Tools.Rights(DataControl.EMAIL.ordinal())), Tools.Dec(Tools.Rights(DataControl.EMAIL.ordinal()))).addOnCompleteListener((Activity) context, task -> {
            if (task.isSuccessful()) {
                new LogicServer(context, dialogLoading, binding).LogicOpenApp(Preference.getValueString(context, Value.SAVE_KEY_LOGIN));
            } else {
                if (task.getException() != null)
                    Toast.makeText(context, "" + task.getException(), Toast.LENGTH_SHORT).show();
                else Toast.makeText(context, R.string.TEXT_ERROR_SERVER, Toast.LENGTH_SHORT).show();
            }
        });
    }

}
