package com.test.jo.tool;

import android.annotation.SuppressLint;
import android.content.Context;

import com.test.jo.R;
import com.test.jo.databinding.ActivityBaseBinding;
import com.test.jo.ui.Base;
import com.test.jo.ui.BaseFloat;

public class Saving {

    public static void SetDefaultDataApp(Context context) {
        if (!Preference.getValueBoolean(context, Value.SAVE_IS_SET_APP_SAVING)) {
            Preference.setValue(context, Value.SAVE_IS_SET_APP_SAVING, Tools.SecurityBool(Value.BOOL_T));
            Preference.setValue(context, Value.SAVE_APP_VERSION_SOCK, "0.0");
            Preference.setValue(context, Value.SAVE_IS_LOGIN, Tools.SecurityBool(Value.BOOL_F));
            Preference.setValue(context, Value.SAVE_KEY_LOGIN, null);

        }
    }

    public static void GetDefaultDataApp(Context context, ActivityBaseBinding binding) {
        binding.SettingSwHideRecorde.setChecked(Preference.getValueBoolean(context, Value.SAVE_APP_IS_HIDE_RECORD));
        Base.Hide_Recorder = Preference.getValueBoolean(context, Value.SAVE_APP_IS_HIDE_RECORD);

    }

    public static void SetDefaultDataFloating(Context context) {
        if (!Preference.getValueBoolean(context, Value.SAVE_APP_IS_GET_DATA)) {
            Preference.setValue(context, Value.SAVE_APP_IS_GET_DATA, Tools.SecurityBool(Value.BOOL_T));
            Preference.setValue(context, Value.SAVE_APP_WIDTH_LINE, 2);
            Preference.setValue(context, Value.SAVE_APP_RADIUS_AFTER_360, 10);
            Preference.setValue(context, Value.SAVE_APP_SIZE_ITEM, 12);
            Preference.setValue(context, Value.SAVE_APP_SIZE_VEHICLE, 12);
            Preference.setValue(context, Value.SAVE_APP_SIZE_INFO, 0);
            Preference.setValue(context, Value.SAVE_APP_UP_INFO, 0);
            Preference.setValue(context, Value.SAVE_APP_DIST_BULLET, 70);
            Preference.setValue(context, Value.SAVE_APP_FOV_BULLET, 100);
            Preference.setValue(context, Value.SAVE_APP_TARGET_MODE, 1);
        }
    }

    @SuppressLint("SetTextI18n")
    public static void GetDefaultDataFloating(Context context) {
        //Radar
        BaseFloat.binding.FloatCbLine.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbLine.getText().toString().trim()));
        BaseFloat.binding.FloatCbSkeleton.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbSkeleton.getText().toString().trim()));
        BaseFloat.binding.FloatCbInfoPlayer.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbInfoPlayer.getText().toString().trim()));
        BaseFloat.binding.FloatCbWeapon.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbWeapon.getText().toString().trim()));
        BaseFloat.binding.FloatCbMark.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMark.getText().toString().trim()));
        BaseFloat.binding.FloatCbHealth.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbHealth.getText().toString().trim()));
        BaseFloat.binding.FloatCbGrenade.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbGrenade.getText().toString().trim()));
        BaseFloat.binding.FloatCbBox.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbBox.getText().toString().trim()));
        BaseFloat.binding.FloatCbDist.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbDist.getText().toString().trim()));
        //-- Setting
        BaseFloat.binding.FloatSbWidthLine.setProgress(Preference.getValueInt(context, Value.SAVE_APP_WIDTH_LINE));
        BaseFloat.binding.FloatSbRadius.setProgress(Preference.getValueInt(context, Value.SAVE_APP_RADIUS_AFTER_360));
        BaseFloat.binding.FloatSbSizeItem.setProgress(Preference.getValueInt(context, Value.SAVE_APP_SIZE_ITEM));
        BaseFloat.binding.FloatSbSizeVehicle.setProgress(Preference.getValueInt(context, Value.SAVE_APP_SIZE_VEHICLE));
        BaseFloat.binding.FloatSbSizeInfo.setProgress(Preference.getValueInt(context, Value.SAVE_APP_SIZE_INFO));
        BaseFloat.binding.FloatSbUpInfo.setProgress(Preference.getValueInt(context, Value.SAVE_APP_UP_INFO));
        BaseFloat.binding.FloatTvWidthLineCount.setText("" + Preference.getValueInt(context, Value.SAVE_APP_WIDTH_LINE));
        BaseFloat.binding.FloatTvRadiusCount.setText("" + Preference.getValueInt(context, Value.SAVE_APP_RADIUS_AFTER_360));
        BaseFloat.binding.FloatTvSizeItemCount.setText("" + Preference.getValueInt(context, Value.SAVE_APP_SIZE_ITEM));
        BaseFloat.binding.FloatTvSizeVehicleCount.setText("" + Preference.getValueInt(context, Value.SAVE_APP_SIZE_VEHICLE));
        BaseFloat.binding.FloatTvSizeInfoCount.setText("" + Preference.getValueInt(context, Value.SAVE_APP_SIZE_INFO));
        BaseFloat.binding.FloatTvUpInfoCount.setText("" + Preference.getValueInt(context, Value.SAVE_APP_UP_INFO));
        //Memory =====
        BaseFloat.binding.FloatSbFovBullet.setProgress(Preference.getValueInt(context, Value.SAVE_APP_FOV_BULLET));
        BaseFloat.binding.FloatSbDistBullet.setProgress(Preference.getValueInt(context, Value.SAVE_APP_DIST_BULLET));
        BaseFloat.binding.FloatSbTargetMode.setProgress(Preference.getValueInt(context, Value.SAVE_APP_TARGET_MODE));
        BaseFloat.binding.FloatTvFovBulletCount.setText("" + Preference.getValueInt(context, Value.SAVE_APP_FOV_BULLET));
        BaseFloat.binding.FloatTvDistBulletCount.setText("" + Preference.getValueInt(context, Value.SAVE_APP_DIST_BULLET));
        if (Preference.getValueInt(context, Value.SAVE_APP_TARGET_MODE) == 1)
            BaseFloat.binding.FloatTvTargetModeCount.setText(R.string.Float_TargetHead);
        else if (Preference.getValueInt(context, Value.SAVE_APP_TARGET_MODE) == 2)
            BaseFloat.binding.FloatTvTargetModeCount.setText(R.string.Float_TargetNick);
        else if (Preference.getValueInt(context, Value.SAVE_APP_TARGET_MODE) == 3)
            BaseFloat.binding.FloatTvTargetModeCount.setText(R.string.Float_TargetBody);
        BaseFloat.binding.FloatCbIsBot.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbIsBot.getText().toString().trim()));
        BaseFloat.binding.FloatCbIsKnock.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbIsKnock.getText().toString().trim()));
        //Items =====
        //iem
        BaseFloat.binding.FloatCbItemDrop.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbItemDrop.getText().toString().trim()));
        BaseFloat.binding.FloatCbItemBox.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbItemBox.getText().toString().trim()));
        BaseFloat.binding.FloatCbItemFlareGun.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbItemFlareGun.getText().toString().trim()));
        BaseFloat.binding.FloatCbItemCoins.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbItemCoins.getText().toString().trim()));
        //Ar
        BaseFloat.binding.FloatCbArAKM.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbArAKM.getText().toString().trim()));
        BaseFloat.binding.FloatCbArM16A4.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbArM16A4.getText().toString().trim()));
        BaseFloat.binding.FloatCbArSCARL.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbArSCARL.getText().toString().trim()));
        BaseFloat.binding.FloatCbArM416.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbArM416.getText().toString().trim()));
        BaseFloat.binding.FloatCbArGROZA.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbArGROZA.getText().toString().trim()));
        BaseFloat.binding.FloatCbArAUG.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbArAUG.getText().toString().trim()));
        BaseFloat.binding.FloatCbArQBZ.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbArQBZ.getText().toString().trim()));
        BaseFloat.binding.FloatCbArM762.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbArM762.getText().toString().trim()));
        BaseFloat.binding.FloatCbArMk47.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbArMk47.getText().toString().trim()));
        BaseFloat.binding.FloatCbAr636C.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbAr636C.getText().toString().trim()));
        BaseFloat.binding.FloatCbArFAMAS.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbArFAMAS.getText().toString().trim()));
        //Sp
        BaseFloat.binding.FloatCbSrKar98k.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbSrKar98k.getText().toString().trim()));
        BaseFloat.binding.FloatCbSrM24.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbSrM24.getText().toString().trim()));
        BaseFloat.binding.FloatCbSrAWM.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbSrAWM.getText().toString().trim()));
        BaseFloat.binding.FloatCbSrWin94.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbSrWin94.getText().toString().trim()));
        BaseFloat.binding.FloatCbSrMosin.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbSrMosin.getText().toString().trim()));
        //Dmr
        BaseFloat.binding.FloatCbMdrSKS.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMdrSKS.getText().toString().trim()));
        BaseFloat.binding.FloatCbMdrVSS.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMdrVSS.getText().toString().trim()));
        BaseFloat.binding.FloatCbMdrMini14.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMdrMini14.getText().toString().trim()));
        BaseFloat.binding.FloatCbMdrMk14.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMdrMk14.getText().toString().trim()));
        BaseFloat.binding.FloatCbMdrSLR.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMdrSLR.getText().toString().trim()));
        BaseFloat.binding.FloatCbMdrQBU.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMdrQBU.getText().toString().trim()));
        BaseFloat.binding.FloatCbMdrMk12.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMdrMk12.getText().toString().trim()));
        //Smg
        BaseFloat.binding.FloatCbSmgUZI.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbSmgUZI.getText().toString().trim()));
        BaseFloat.binding.FloatCbSmgUMP45.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbSmgUMP45.getText().toString().trim()));
        BaseFloat.binding.FloatCbSmgVector.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbSmgVector.getText().toString().trim()));
        BaseFloat.binding.FloatCbSmgBizon.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbSmgBizon.getText().toString().trim()));
        BaseFloat.binding.FloatCbSmgThompson.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbSmgThompson.getText().toString().trim()));
        BaseFloat.binding.FloatCbSmgMP5K.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbSmgMP5K.getText().toString().trim()));
        BaseFloat.binding.FloatCbSmgP90.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbSmgP90.getText().toString().trim()));
        //shotgun
        BaseFloat.binding.FloatCbShotgunS686.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbShotgunS686.getText().toString().trim()));
        BaseFloat.binding.FloatCbShotgunS1897.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbShotgunS1897.getText().toString().trim()));
        BaseFloat.binding.FloatCbShotgunS12k.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbShotgunS12k.getText().toString().trim()));
        BaseFloat.binding.FloatCbShotgunDBS.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbShotgunDBS.getText().toString().trim()));
        BaseFloat.binding.FloatCbShotgunM1014.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbShotgunM1014.getText().toString().trim()));
        //Lmg
        BaseFloat.binding.FloatCbLmgM249.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbLmgM249.getText().toString().trim()));
        BaseFloat.binding.FloatCbLmgDP28.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbLmgDP28.getText().toString().trim()));
        BaseFloat.binding.FloatCbLmgM163.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbLmgM163.getText().toString().trim()));
        //Scope
        BaseFloat.binding.FloatCbScopeX8.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbScopeX8.getText().toString().trim()));
        BaseFloat.binding.FloatCbScopeX6.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbScopeX6.getText().toString().trim()));
        BaseFloat.binding.FloatCbScopeX4.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbScopeX4.getText().toString().trim()));
        BaseFloat.binding.FloatCbScopeX3.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbScopeX3.getText().toString().trim()));
        BaseFloat.binding.FloatCbScopeX2.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbScopeX2.getText().toString().trim()));
        BaseFloat.binding.FloatCbScopeRedPoint.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbScopeRedPoint.getText().toString().trim()));
        //Melee
        BaseFloat.binding.FloatCbMeleePan.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMeleePan.getText().toString().trim()));
        BaseFloat.binding.FloatCbMeleeMachete.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMeleeMachete.getText().toString().trim()));
        BaseFloat.binding.FloatCbMeleeCrowbar.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMeleeCrowbar.getText().toString().trim()));
        BaseFloat.binding.FloatCbPistolSickle.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbPistolSickle.getText().toString().trim()));
        //Other
        BaseFloat.binding.FloatCbOtherCrossbow.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbOtherCrossbow.getText().toString().trim()));
        //Helmet
        BaseFloat.binding.FloatCbHelmetLv1.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbHelmetLv1.getText().toString().trim()));
        BaseFloat.binding.FloatCbHelmetLv2.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbHelmetLv2.getText().toString().trim()));
        BaseFloat.binding.FloatCbHelmetLv3.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbHelmetLv3.getText().toString().trim()));
        //Armor
        BaseFloat.binding.FloatCbArmorLv1.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbArmorLv1.getText().toString().trim()));
        BaseFloat.binding.FloatCbArmorLv2.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbArmorLv2.getText().toString().trim()));
        BaseFloat.binding.FloatCbArmorLv3.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbArmorLv3.getText().toString().trim()));
        //BackPack
        BaseFloat.binding.FloatCbBackpackLv1.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbBackpackLv1.getText().toString().trim()));
        BaseFloat.binding.FloatCbBackpackLv2.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbBackpackLv2.getText().toString().trim()));
        BaseFloat.binding.FloatCbBackpackLv3.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbBackpackLv3.getText().toString().trim()));
        //Mad kit
        BaseFloat.binding.FloatCbMadKitEnergy.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMadKitEnergy.getText().toString().trim()));
        BaseFloat.binding.FloatCbMadKitAdrenaline.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMadKitAdrenaline.getText().toString().trim()));
        BaseFloat.binding.FloatCbMadKitPainkiller.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMadKitPainkiller.getText().toString().trim()));
        BaseFloat.binding.FloatCbMadKitBandages.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMadKitBandages.getText().toString().trim()));
        BaseFloat.binding.FloatCbMadKitFirst.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMadKitFirst.getText().toString().trim()));
        BaseFloat.binding.FloatCbMadKitMadKit.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMadKitMadKit.getText().toString().trim()));
        BaseFloat.binding.FloatCbMadKitFuel.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMadKitFuel.getText().toString().trim()));
        //Muzzle
        BaseFloat.binding.FloatCbMuzzleCompensator.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMuzzleCompensator.getText().toString().trim()));
        BaseFloat.binding.FloatCbMuzzleVertical.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMuzzleVertical.getText().toString().trim()));
        BaseFloat.binding.FloatCbMuzzleEQAr.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMuzzleEQAr.getText().toString().trim()));
        BaseFloat.binding.FloatCbMuzzleEQSp.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMuzzleEQSp.getText().toString().trim()));
        BaseFloat.binding.FloatCbMuzzleEQSmg.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMuzzleEQSmg.getText().toString().trim()));
        BaseFloat.binding.FloatCbMuzzleEAr.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMuzzleEAr.getText().toString().trim()));
        BaseFloat.binding.FloatCbMuzzleESmg.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMuzzleESmg.getText().toString().trim()));
        BaseFloat.binding.FloatCbMuzzleESp.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMuzzleESp.getText().toString().trim()));
        //Vehicle
        BaseFloat.binding.FloatCbVehicleUAZ.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleUAZ.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleBRDM.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleBRDM.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleBus.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleBus.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleUTV.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleUTV.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleMonster.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleMonster.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehiclePickUp.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehiclePickUp.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleRony.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleRony.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleDacia.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleDacia.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleCoupe.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleCoupe.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleMirado.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleMirado.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleTukshai.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleTukshai.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleSidecar.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleSidecar.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleSnowmobile.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleSnowmobile.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleSnowbike.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleSnowbike.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleMotorcycle.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleMotorcycle.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleScooter.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleScooter.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleBuggy.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleBuggy.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehiclePG117.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehiclePG117.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleAquaRail.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleAquaRail.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleGlider.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleGlider.getText().toString().trim()));
        BaseFloat.binding.FloatCbVehicleBicycle.setChecked(Preference.getValueBoolean(context, BaseFloat.binding.FloatCbVehicleBicycle.getText().toString().trim()));
        //-- Send ToC++
        Tools.SecurityWidget(context, DataControl.LINE.ordinal(), 0, Preference.getValueBoolean(context, BaseFloat.binding.FloatCbLine.getText().toString().trim()));
        Tools.SecurityWidget(context, DataControl.SKELETON.ordinal(), 0, Preference.getValueBoolean(context, BaseFloat.binding.FloatCbSkeleton.getText().toString().trim()));
        Tools.SecurityWidget(context, DataControl.INFO_PLAYER.ordinal(), 0, Preference.getValueBoolean(context, BaseFloat.binding.FloatCbInfoPlayer.getText().toString().trim()));
        Tools.SecurityWidget(context, DataControl.WEAPON.ordinal(), 0, Preference.getValueBoolean(context, BaseFloat.binding.FloatCbWeapon.getText().toString().trim()));
        Tools.SecurityWidget(context, DataControl.MARK.ordinal(), 0, Preference.getValueBoolean(context, BaseFloat.binding.FloatCbMark.getText().toString().trim()));
        Tools.SecurityWidget(context, DataControl.HEALTH.ordinal(), 0, Preference.getValueBoolean(context, BaseFloat.binding.FloatCbHealth.getText().toString().trim()));
        Tools.SecurityWidget(context, DataControl.GRENADE.ordinal(), 0, Preference.getValueBoolean(context, BaseFloat.binding.FloatCbGrenade.getText().toString().trim()));
        Tools.SecurityWidget(context, DataControl.BOX.ordinal(), 0, Preference.getValueBoolean(context, BaseFloat.binding.FloatCbBox.getText().toString().trim()));
        Tools.SecurityWidget(context, DataControl.DIST.ordinal(), 0, Preference.getValueBoolean(context, BaseFloat.binding.FloatCbDist.getText().toString().trim()));
        Tools.SecurityWidget(context, DataControl.BOT.ordinal(), 0, Preference.getValueBoolean(context, BaseFloat.binding.FloatCbIsBot.getText().toString().trim()));
        Tools.SecurityWidget(context, DataControl.KNOCK.ordinal(), 0, Preference.getValueBoolean(context, BaseFloat.binding.FloatCbIsKnock.getText().toString().trim()));

        //--
        Tools.SecurityWidget(context, DataControl.WIDTH_LINE.ordinal(), Preference.getValueInt(context, Value.SAVE_APP_WIDTH_LINE), Tools.SecurityBool(Value.BOOL_F));
        Tools.SecurityWidget(context, DataControl.RADIUS360.ordinal(), Preference.getValueInt(context, Value.SAVE_APP_RADIUS_AFTER_360), Tools.SecurityBool(Value.BOOL_F));
        Tools.SecurityWidget(context, DataControl.SIZE_ITEM.ordinal(), Preference.getValueInt(context, Value.SAVE_APP_SIZE_ITEM), Tools.SecurityBool(Value.BOOL_F));
        Tools.SecurityWidget(context, DataControl.SIZE_VEHICLE.ordinal(), Preference.getValueInt(context, Value.SAVE_APP_SIZE_VEHICLE), Tools.SecurityBool(Value.BOOL_F));
        Tools.SecurityWidget(context, DataControl.SIZE_INFO.ordinal(), Preference.getValueInt(context, Value.SAVE_APP_SIZE_INFO), Tools.SecurityBool(Value.BOOL_F));
        Tools.SecurityWidget(context, DataControl.UP_INFO.ordinal(), Preference.getValueInt(context, Value.SAVE_APP_UP_INFO), Tools.SecurityBool(Value.BOOL_F));
        Tools.SecurityWidget(context, DataControl.FOV_BULLET.ordinal(), Preference.getValueInt(context, Value.SAVE_APP_FOV_BULLET), Tools.SecurityBool(Value.BOOL_F));
        Tools.SecurityWidget(context, DataControl.DIST_BULLET.ordinal(), Preference.getValueInt(context, Value.SAVE_APP_DIST_BULLET), Tools.SecurityBool(Value.BOOL_F));
        Tools.SecurityWidget(context, DataControl.TARGET_MODE.ordinal(), Preference.getValueInt(context, Value.SAVE_APP_TARGET_MODE), Tools.SecurityBool(Value.BOOL_F));
    }
}