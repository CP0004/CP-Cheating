package com.test.jo.ui;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.IBinder;
import android.view.ContextThemeWrapper;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.test.jo.R;
import com.test.jo.databinding.WindowFloatingBinding;
import com.test.jo.draw.HideRecorder;
import com.test.jo.draw.Overlay;
import com.test.jo.tool.Activity;
import com.test.jo.tool.Animation;
import com.test.jo.tool.DataControl;
import com.test.jo.tool.GestureDetectors;
import com.test.jo.tool.Saving;
import com.test.jo.tool.Tools;
import com.test.jo.tool.Value;

public class BaseFloat extends Service {

    @SuppressLint("StaticFieldLeak")
    public static WindowFloatingBinding binding;
    @SuppressLint("StaticFieldLeak")
    private ContextThemeWrapper contextThemeWrapper;
    private GestureDetector gestureDetector;
    private View view;
    private WindowManager manager;
    private WindowManager.LayoutParams params;
    private float touchX, touchY;
    private int posX, posY;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onCreate() {
        super.onCreate();
        contextThemeWrapper = new ContextThemeWrapper(this, R.style.Theme_TEST);
        CreateOverly(contextThemeWrapper);
        gestureDetector = new GestureDetector(this, new GestureDetectors());
        binding = WindowFloatingBinding.bind(view);
        Activity.GoneFloatWindow(this, binding);
        Activity.VisibleLayoutRadar(getApplicationContext(), binding);
        Saving.SetDefaultDataFloating(this);
        Saving.GetDefaultDataFloating(this);

        //Move Layout Root and onClick
        binding.FloatLayRoot.setOnTouchListener((viewV, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    //Get Touch Y,X
                    posX = params.x;
                    posY = params.y;
                    touchX = event.getRawX();
                    touchY = event.getRawY();

                    return true;
                case MotionEvent.ACTION_MOVE:
                    //Move
                    params.x = posX + (int) (event.getRawX() - touchX);
                    params.y = posY + (int) (event.getRawY() - touchY);
                    //update Touch
                    manager.updateViewLayout(view, params);
                    return true;
            }
            return false;
        });

        //Move Img Root and onClick
        binding.FloatImgRoot.setOnTouchListener((viewV, event) -> {
            if (gestureDetector.onTouchEvent(event)) {
                //set Visibility window and icon
                Activity.VisibleFloatWindow(this, binding);
                return true;
            } else {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        //Get Touch Y,X
                        posX = params.x;
                        posY = params.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Move
                        params.x = posX + (int) (event.getRawX() - touchX);
                        params.y = posY + (int) (event.getRawY() - touchY);
                        //update Touch
                        manager.updateViewLayout(view, params);
                        return true;
                }
                return false;
            }
        });

        binding.FloatBtnRadar.setOnClickListener(v -> Activity.VisibleLayoutRadar(getApplicationContext(), binding));
        binding.FloatBtnItem.setOnClickListener(v -> Activity.VisibleLayoutItems(getApplicationContext(), binding));
        binding.FloatBtnMemory.setOnClickListener(v -> {
            if (Tools.CheckMemory()) {
                Activity.VisibleLayoutMemory(getApplicationContext(), binding);
            } else {
                Animation.AnimateBounce(binding.FloatBtnMemory, this);
                Toast.makeText(this, R.string.TEXT_NOT_SAFE, Toast.LENGTH_SHORT).show();
            }
        });
        binding.FloatBtnSetting.setOnClickListener(v -> Activity.VisibleLayoutSetting(getApplicationContext(), binding));
        binding.FloatBtnClose.setOnClickListener(v -> Activity.GoneFloatWindow(this, binding));
        binding.FloatBtnFixFreezingDrawing.setOnClickListener(v -> {
            Animation.AnimateBounce(binding.FloatBtnFixFreezingDrawing, this);
            stopService(new Intent(this, Overlay.class));
            new Handler().postDelayed(() -> startService(new Intent(this, Overlay.class)), 1500);
        });

        binding.FloatSwHideItems.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                startService(new Intent(this, BaseHideItem.class));
            } else {
                Tools.LinkValue(DataControl.HIDE_ITEMS.ordinal(), 0, true);
                stopService(new Intent(this, BaseHideItem.class));
            }

        });

        //-- Radar
        Tools.OnChecked(this, binding.FloatCbLine, true, DataControl.LINE.ordinal(), true);
        Tools.OnChecked(this, binding.FloatCbSkeleton, true, DataControl.SKELETON.ordinal(), true);
        Tools.OnChecked(this, binding.FloatCbInfoPlayer, true, DataControl.INFO_PLAYER.ordinal(), true);
        Tools.OnChecked(this, binding.FloatCbWeapon, true, DataControl.WEAPON.ordinal(), true);
        Tools.OnChecked(this, binding.FloatCbMark, true, DataControl.MARK.ordinal(), true);
        Tools.OnChecked(this, binding.FloatCbHealth, true, DataControl.HEALTH.ordinal(), true);
        Tools.OnChecked(this, binding.FloatCbGrenade, true, DataControl.GRENADE.ordinal(), true);
        Tools.OnChecked(this, binding.FloatCbBox, true, DataControl.BOX.ordinal(), true);
        Tools.OnChecked(this, binding.FloatCbDist, true, DataControl.DIST.ordinal(), true);
        //-- Memory
        Tools.OnChecked(this, binding.FloatCbLess, true, DataControl.LESS.ordinal(), true);
        Tools.OnChecked(this, binding.FloatCbCrossHair, true, DataControl.CROSS_HAIR.ordinal(), true);
        Tools.OnChecked(this, binding.FloatCbAimBot, true, DataControl.AIMBOT.ordinal(), true);
        Tools.OnChecked(this, binding.FloatCbBulletTrack, true, DataControl.BULLET.ordinal(), true);
        Tools.OnChecked(this, binding.FloatCbInstaHit, true, 100, true);
        Tools.OnChecked(this, binding.FloatCbHeadShoot, true, 100, true);
        Tools.OnSeekBar(this, binding.FloatSbIPadView, binding.FloatTvIPadViewCount, "", DataControl.IPAD_VIEW.ordinal());
        Tools.OnSeekBar(this, binding.FloatSbDistBullet, binding.FloatTvDistBulletCount, Value.SAVE_APP_DIST_BULLET, DataControl.DIST_BULLET.ordinal());
        Tools.OnSeekBar(this, binding.FloatSbFovBullet, binding.FloatTvFovBulletCount, Value.SAVE_APP_FOV_BULLET, DataControl.FOV_BULLET.ordinal());
        Tools.OnSeekBar(this, binding.FloatSbTargetMode, binding.FloatTvTargetModeCount, Value.SAVE_APP_TARGET_MODE, DataControl.TARGET_MODE.ordinal());
        Tools.OnChecked(this, binding.FloatCbIsBot, true, DataControl.BOT.ordinal(), true);
        Tools.OnChecked(this, binding.FloatCbIsKnock, true, DataControl.KNOCK.ordinal(), true);
        //-- Setting
        Tools.OnSeekBar(this, binding.FloatSbWidthLine, binding.FloatTvWidthLineCount, Value.SAVE_APP_WIDTH_LINE, DataControl.WIDTH_LINE.ordinal());
        Tools.OnSeekBar(this, binding.FloatSbRadius, binding.FloatTvRadiusCount, Value.SAVE_APP_RADIUS_AFTER_360, DataControl.RADIUS360.ordinal());
        Tools.OnSeekBar(this, binding.FloatSbSizeItem, binding.FloatTvSizeItemCount, Value.SAVE_APP_SIZE_ITEM, DataControl.SIZE_ITEM.ordinal());
        Tools.OnSeekBar(this, binding.FloatSbSizeVehicle, binding.FloatTvSizeVehicleCount, Value.SAVE_APP_SIZE_VEHICLE, DataControl.SIZE_VEHICLE.ordinal());
        Tools.OnSeekBar(this, binding.FloatSbSizeInfo, binding.FloatTvSizeInfoCount, Value.SAVE_APP_SIZE_INFO, DataControl.SIZE_INFO.ordinal());
        Tools.OnSeekBar(this, binding.FloatSbUpInfo, binding.FloatTvUpInfoCount, Value.SAVE_APP_UP_INFO, DataControl.UP_INFO.ordinal());
        //Items =====

        //item
        Tools.OnChecked(this, binding.FloatCbItemDrop, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbItemBox, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbItemCoins, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbItemFlareGun, true, 0, true);
        //Ar
        Tools.OnChecked(this, binding.FloatCbArAKM, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbArM16A4, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbArSCARL, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbArM416, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbArGROZA, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbArAUG, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbArQBZ, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbArM762, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbArMk47, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbAr636C, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbArFAMAS, true, 0, true);
        //Sp
        Tools.OnChecked(this, binding.FloatCbSrKar98k, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbSrM24, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbSrAWM, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbSrWin94, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbSrMosin, true, 0, true);
        //Dmr
        Tools.OnChecked(this, binding.FloatCbMdrSKS, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMdrVSS, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMdrMini14, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMdrMk14, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMdrSLR, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMdrQBU, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMdrMk12, true, 0, true);
        //Smg
        Tools.OnChecked(this, binding.FloatCbSmgUZI, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbSmgUMP45, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbSmgVector, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbSmgBizon, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbSmgThompson, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbSmgMP5K, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbSmgP90, true, 0, true);
        //Shotgun
        Tools.OnChecked(this, binding.FloatCbShotgunS686, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbShotgunS1897, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbShotgunS12k, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbShotgunDBS, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbShotgunM1014, true, 0, true);
        //Lmg
        Tools.OnChecked(this, binding.FloatCbLmgM249, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbLmgDP28, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbLmgM163, true, 0, true);
        //Pistol
        Tools.OnChecked(this, binding.FloatCbScopeX8, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbScopeX6, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbScopeX4, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbScopeX3, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbScopeX2, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbScopeRedPoint, true, 0, true);
        //Melee
        Tools.OnChecked(this, binding.FloatCbMeleePan, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMeleeMachete, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMeleeCrowbar, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbPistolSickle, true, 0, true);
        //Other
        Tools.OnChecked(this, binding.FloatCbOtherCrossbow, true, 0, true);
        //Helmet
        Tools.OnChecked(this, binding.FloatCbHelmetLv1, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbHelmetLv2, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbHelmetLv3, true, 0, true);
        //Armor
        Tools.OnChecked(this, binding.FloatCbArmorLv1, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbArmorLv2, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbArmorLv3, true, 0, true);
        //BackPack
        Tools.OnChecked(this, binding.FloatCbBackpackLv1, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbBackpackLv2, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbBackpackLv3, true, 0, true);
        //Mad Kit
        Tools.OnChecked(this, binding.FloatCbMadKitEnergy, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMadKitAdrenaline, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMadKitPainkiller, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMadKitBandages, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMadKitFirst, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMadKitMadKit, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMadKitFuel, true, 0, true);
        //Muzzle
        Tools.OnChecked(this, binding.FloatCbMuzzleCompensator, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMuzzleVertical, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMuzzleEQAr, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMuzzleEQSp, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMuzzleEQSmg, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMuzzleEAr, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMuzzleESp, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbMuzzleESmg, true, 0, true);
        //Vehicle
        Tools.OnChecked(this, binding.FloatCbVehicleUAZ, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleBRDM, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleBus, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleUTV, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleMonster, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehiclePickUp, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleRony, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleDacia, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleCoupe, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleMirado, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleTukshai, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleSidecar, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleSnowmobile, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleSnowbike, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleMotorcycle, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleScooter, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleBuggy, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehiclePG117, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleAquaRail, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleGlider, true, 0, true);
        Tools.OnChecked(this, binding.FloatCbVehicleBicycle, true, 0, true);
    }

    //Show overly Window
    @SuppressLint({"InflateParams", "RtlHardcoded"})
    void CreateOverly(ContextThemeWrapper context) {
        manager = (WindowManager) getSystemService(WINDOW_SERVICE);
        view = LayoutInflater.from(context).inflate(R.layout.window_floating, null);
        //setting show window
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        if (Base.Hide_Recorder)
            HideRecorder.setFakeRecorderWindowLayoutParams(params);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 500;
        params.y = 500;
        manager.addView(view, params);

    }

    //check off or on class
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (view != null) {
            manager.removeView(view);
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}