package com.test.jo.ui;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import androidx.annotation.Nullable;

import com.test.jo.R;
import com.test.jo.databinding.WindowHideItemBinding;
import com.test.jo.draw.HideRecorder;
import com.test.jo.tool.DataControl;
import com.test.jo.tool.GestureDetectors;
import com.test.jo.tool.Tools;

public class BaseHideItem extends Service {

    @SuppressLint("StaticFieldLeak")
    public static WindowHideItemBinding binding;
    @SuppressLint("StaticFieldLeak")
    private GestureDetector gestureDetector;
    private View view;
    private WindowManager manager;
    private WindowManager.LayoutParams params;
    private float touchX, touchY;
    private int posX, posY, onClickButton;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onCreate() {
        super.onCreate();
        CreateOverly(this);
        gestureDetector = new GestureDetector(this, new GestureDetectors());
        binding = WindowHideItemBinding.bind(view);


        //Move Img Root and onClick
        binding.FloatImgRoot.setOnTouchListener((viewV, event) -> {
            if (gestureDetector.onTouchEvent(event)) {
                if (onClickButton == 0) {
                    binding.FloatImgRoot.setColorFilter(Color.parseColor("#EFB301"));
                    onClickButton = 1;
                    Tools.LinkValue(DataControl.HIDE_ITEMS.ordinal(), 0, true);
                } else {
                    binding.FloatImgRoot.setColorFilter(Color.parseColor("#E5E5E5"));
                    onClickButton = 0;
                    Tools.LinkValue(DataControl.HIDE_ITEMS.ordinal(), 0, false);
                }

                return true;
            } else {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        //Get Touch Y,X
                        posX = params.x;
                        posY = params.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Move
                        params.x = posX + (int) (event.getRawX() - touchX);
                        params.y = posY + (int) (event.getRawY() - touchY);
                        //update Touch
                        manager.updateViewLayout(view, params);
                        return true;
                }
                return false;
            }
        });
    }

    //Show overly Window
    @SuppressLint({"InflateParams", "RtlHardcoded"})
    void CreateOverly(Context context) {
        manager = (WindowManager) getSystemService(WINDOW_SERVICE);
        view = LayoutInflater.from(context).inflate(R.layout.window_hide_item, null);
        //setting show window
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        if (Base.Hide_Recorder)
            HideRecorder.setFakeRecorderWindowLayoutParams(params);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 500;
        params.y = 500;
        manager.addView(view, params);

    }

    //check off or on class
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (view != null) {
            manager.removeView(view);
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


}
