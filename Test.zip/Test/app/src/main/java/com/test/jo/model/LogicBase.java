package com.test.jo.model;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import com.test.jo.draw.Overlay;
import com.test.jo.tool.Tools;
import com.test.jo.ui.BaseFloat;
import com.test.jo.ui.BaseHideItem;

public class LogicBase {

    private final Context context;

    public LogicBase(Context context) {
        this.context = context;
    }

    @SuppressLint("SetTextI18n")
    public void StartCheating() {
        if (Tools.CheckVip() && Tools.CheckVersionApp() == Float.parseFloat(Tools.GetVersion(context))) {
            context.startService(new Intent(context, Overlay.class));
            context.startService(new Intent(context, BaseFloat.class));
        }
    }

    public void StopCheating() {
        if (Tools.CheckVip() && Tools.CheckVersionApp() == Float.parseFloat(Tools.GetVersion(context))) {
            context.stopService(new Intent(context, Overlay.class));
            context.stopService(new Intent(context, BaseFloat.class));
            context.stopService(new Intent(context, BaseHideItem.class));
        }
    }
}