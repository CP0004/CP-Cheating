package com.test.jo.draw;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.view.View;

import androidx.annotation.Keep;

import com.test.jo.ui.BaseFloat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

@Keep
public class Draw extends View implements Runnable {
    Paint mStrokePaint;
    Paint mFilledPaint, mFilledPaint2;
    Paint mTextPaint;
    Thread mThread;
    int FPS = 60;
    static long sleepTime;
    Date time;
    SimpleDateFormat formatter;

    public Draw(Context context) {
        super(context, null, 0);
        InitializePaints();
        setFocusableInTouchMode(false);
        setBackgroundColor(Color.TRANSPARENT);
        time = new Date();
        formatter = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        sleepTime = 1000 / FPS;
        mThread = new Thread(this);
        mThread.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (canvas != null && getVisibility() == VISIBLE) {
            ClearCanvas(canvas);
            Overlay.DrawOn(this, canvas);
        }
    }

    @Override
    public void run() {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
        while (mThread.isAlive() && !mThread.isInterrupted()) {
            try {
                long t1 = System.currentTimeMillis();
                postInvalidate();
                long td = System.currentTimeMillis() - t1;

                Thread.sleep(Math.max(Math.min(0, sleepTime - td), sleepTime));
            } catch (Exception e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    public void InitializePaints() {
        mStrokePaint = new Paint();
        mStrokePaint.setStyle(Paint.Style.STROKE);
        mStrokePaint.setAntiAlias(true);
        mStrokePaint.setColor(Color.rgb(0, 0, 0));

        mFilledPaint = new Paint();
        mFilledPaint.setStyle(Paint.Style.FILL);
        mFilledPaint.setAntiAlias(true);
        mFilledPaint.setColor(Color.rgb(0, 0, 0));

        mFilledPaint2 = new Paint();
        mFilledPaint2.setStyle(Paint.Style.FILL);
        mFilledPaint2.setAntiAlias(true);
        mFilledPaint2.setColor(Color.rgb(0, 0, 0));

        mTextPaint = new Paint();
        mTextPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        mTextPaint.setAntiAlias(true);
        mTextPaint.setColor(Color.rgb(0, 0, 0));
        mTextPaint.setTextAlign(Paint.Align.CENTER);
        mTextPaint.setStrokeWidth(0.5f);

    }

    public void ClearCanvas(Canvas cvs) {
        cvs.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
    }

    //Line
    public void DrawLine(Canvas cvs, int a, int r, int g, int b, float lineWidth, float fromX, float fromY, float toX, float toY) {
        mStrokePaint.setColor(Color.rgb(r, g, b));
        mStrokePaint.setAlpha(a);
        mStrokePaint.setStrokeWidth(lineWidth);
        cvs.drawLine(fromX, fromY, toX, toY, mStrokePaint);
    }

    //RectStock
    public void DrawRect(Canvas cvs, int a, int r, int g, int b, float strokes, float x, float y, float width, float height) {
        mStrokePaint.setStrokeWidth(strokes);
        mStrokePaint.setColor(Color.rgb(r, g, b));
        mStrokePaint.setAlpha(a);
        cvs.drawRect(x, y, width, height, mStrokePaint);
    }

    //RectFill
    public void DrawFilledRect(Canvas cvs, int a, int r, int g, int b, float x, float y, float width, float height) {
        mFilledPaint.setColor(Color.rgb(r, g, b));
        mFilledPaint.setAlpha(a);
        cvs.drawRect(x, y, width, height, mFilledPaint);
    }

    //Text All
    public void DrawText(Canvas cvs, int a, int r, int g, int b, String txt, float posX, float posY, float size) {
        mTextPaint.setARGB(a, r, g, b);
        mTextPaint.setTextSize(size);
        cvs.drawText(txt, posX, posY, mTextPaint);
    }

    //Circle Stroke
    public void DrawCircle(Canvas cvs, int a, int r, int g, int b, float posX, float posY, float radius, float strokeZ) {
        mStrokePaint.setColor(Color.rgb(r, g, b));
        mStrokePaint.setAlpha(a);
        mStrokePaint.setStrokeWidth(strokeZ);
        cvs.drawCircle(posX, posY, radius, mStrokePaint);
    }

    //Circle Fill
    public void DrawFilledCircle(Canvas cvs, int a, int r, int g, int b, float posX, float posY, float radius) {
        mFilledPaint.setColor(Color.rgb(r, g, b));
        mFilledPaint.setAlpha(a);
        cvs.drawCircle(posX, posY, radius, mFilledPaint);
    }

    private String Nation(String code) {
        if (code.equals("G1"))
            code = "Guest";
        else
            code = new String(Character.toChars((Character.codePointAt(code, 0) - 65) + 127462)) + new String(Character.toChars((Character.codePointAt(code, 1) - 65) + 127462));
        return code;
    }

    public void DrawWeapon(Canvas cvs, int a, int r, int g, int b, int id, int ammo, float posX, float posY, float size) {
        mTextPaint.setARGB(a, r, g, b);
        mTextPaint.setTextSize(size);
        String nameWeapon = GetWeapon(id);
        if (nameWeapon != null) cvs.drawText(nameWeapon, posX, posY, mTextPaint);
    }

    //Item Show
    public void DrawItems(Canvas cvs, String itemName, float distance, float posX, float posY, float size) {
        mTextPaint.setColor(Color.argb(255, 80, 173, 204));
        mTextPaint.setTextSize(size);

        if (ObjectItems(itemName) != null) if (ObjectItems(itemName).equals("AirDropBox")) {
            cvs.drawText(ObjectItems(itemName) + "  -  " + Math.round(distance), posX, posY, mTextPaint);
        } else {
            cvs.drawText(ObjectItems(itemName), posX, posY, mTextPaint);
        }
    }

    // -- Convert Char To String
    public String CharToString(String text) {
        String[] namespace = text.split(":");
        char[] naming = new char[namespace.length];
        for (int i = 0; i < namespace.length; i++)
            naming[i] = (char) Integer.parseInt(namespace[i]);
        return new String(naming);
    }

    public void InfoPLayer(Canvas cvs, int a, int r, int g, int b, int teamId, String namePlayer, String flagPlayer, float posX, float posY, float size) {
        mTextPaint.setARGB(a, r, g, b);
        mTextPaint.setTextSize(size);
        cvs.drawText(teamId + "  -  " + Nation(CharToString(flagPlayer)) + "  -  " + CharToString(namePlayer), posX, posY, mTextPaint);
    }

    //Vehicles Show (filter)
    public void DrawVehicles(Canvas cvs, String VehiclesName, float distance, float posX, float posY, float size, int hp, int fuel, boolean isAim) {
        mTextPaint.setColor(Color.argb(255, 189, 226, 255));
        mTextPaint.setTextSize(size);
        if (ObjectVehicle(VehiclesName) != null) {
            cvs.drawText(ObjectVehicle(VehiclesName), posX, posY, mTextPaint);
            cvs.drawText("Dist: " + (int) distance, posX, posY + ((7 + size) * 1), mTextPaint);
        }
    }

    public String ObjectVehicle(String name) {
        if (BaseFloat.binding.FloatCbVehicleBuggy.isChecked() && name.contains("Buggy")) {
            return "Buggy";
        } else if (BaseFloat.binding.FloatCbVehicleBRDM.isChecked() && name.contains("BRDM")) {
            return "BRDM";
        } else if (BaseFloat.binding.FloatCbVehicleBus.isChecked() && name.contains("Bus")) {
            return "Bus";
        } else if (BaseFloat.binding.FloatCbVehicleUTV.isChecked() && name.contains("UTV")) {
            return "UTV";
        } else if (BaseFloat.binding.FloatCbVehicleMonster.isChecked() && name.contains("Bigfoot")) {
            return "Monster";
        } else if (BaseFloat.binding.FloatCbVehiclePickUp.isChecked() && name.contains("PickUp")) {
            return "PickUp";
        } else if (BaseFloat.binding.FloatCbVehicleRony.isChecked() && name.contains("Rony")) {
            return "Rony";
        } else if (BaseFloat.binding.FloatCbVehicleDacia.isChecked() && name.contains("Dacia")) {
            return "Dacia";
        } else if (BaseFloat.binding.FloatCbVehicleCoupe.isChecked() && name.contains("CoupeRB")) {
            return "Coupe";
        } else if (BaseFloat.binding.FloatCbVehicleMirado.isChecked() && name.contains("Mirado")) {
            return "Mirado";
        } else if (BaseFloat.binding.FloatCbVehicleTukshai.isChecked() && name.contains("Tuk")) {
            return "Tukshai";
        } else if (BaseFloat.binding.FloatCbVehicleUAZ.isChecked() && name.contains("UAZ")) {
            return "UAZ";
        } else if (BaseFloat.binding.FloatCbVehicleSidecar.isChecked() && name.contains("MotorcycleC")) {
            return "Sidecar";
        } else if (BaseFloat.binding.FloatCbVehicleSnowmobile.isChecked() && name.contains("Snowmobile")) {
            return "Snowmobile";
        } else if (BaseFloat.binding.FloatCbVehicleSnowbike.isChecked() && name.contains("Snowbike")) {
            return "Snowbike";
        } else if (BaseFloat.binding.FloatCbVehicleMotorcycle.isChecked() && name.contains("Motorcycle")) {
            return "Motorcycle";
        } else if (BaseFloat.binding.FloatCbVehicleScooter.isChecked() && name.contains("Scooter")) {
            return "Scooter";
        } else if (BaseFloat.binding.FloatCbVehiclePG117.isChecked() && name.contains("PG117")) {
            return "PG117";
        } else if (BaseFloat.binding.FloatCbVehicleAquaRail.isChecked() && name.contains("AquaRail")) {
            return "AquaRail";
        } else if (BaseFloat.binding.FloatCbVehicleGlider.isChecked() && name.contains("Motorglider")) {
            return "Glider";
        } else if (BaseFloat.binding.FloatCbVehicleGlider.isChecked() && name.contains("Bike")) {
            return "Bicycle";
        } else {
            return null;
        }
    }

    public String ObjectItems(String name) {
        //AR
        if (BaseFloat.binding.FloatCbArAKM.isChecked() && name.contains("AKM")) {
            mTextPaint.setColor(Color.argb(255, 250, 255, 117));
            return "AKM";
        } else if (BaseFloat.binding.FloatCbArM16A4.isChecked() && name.contains("M16A4")) {
            mTextPaint.setColor(Color.argb(255, 250, 255, 117));
            return "M16A4";
        } else if (BaseFloat.binding.FloatCbArSCARL.isChecked() && name.contains("SCAR")) {
            mTextPaint.setColor(Color.argb(255, 250, 255, 117));
            return "SCAR-L";
        } else if (BaseFloat.binding.FloatCbArM416.isChecked() && name.contains("M416")) {
            mTextPaint.setColor(Color.argb(255, 250, 255, 117));
            return "M416";
        } else if (BaseFloat.binding.FloatCbArGROZA.isChecked() && name.contains("Groza")) {
            mTextPaint.setColor(Color.argb(255, 250, 255, 117));
            return "Groza";
        } else if (BaseFloat.binding.FloatCbArAUG.isChecked() && name.contains("AUG")) {
            mTextPaint.setColor(Color.argb(255, 250, 255, 117));
            return "AUG";
        } else if (BaseFloat.binding.FloatCbArQBZ.isChecked() && name.contains("QBZ")) {
            mTextPaint.setColor(Color.argb(255, 250, 255, 117));
            return "QBZ";
        } else if (BaseFloat.binding.FloatCbArM762.isChecked() && name.contains("M762")) {
            mTextPaint.setColor(Color.argb(255, 250, 255, 117));
            return "M762";
        } else if (BaseFloat.binding.FloatCbArMk47.isChecked() && name.contains("Mk47")) {
            mTextPaint.setColor(Color.argb(255, 250, 255, 117));
            return "Mk47";
        } else if (BaseFloat.binding.FloatCbAr636C.isChecked() && name.contains("G36")) {
            mTextPaint.setColor(Color.argb(255, 250, 255, 117));
            return "636C";
        } else if (BaseFloat.binding.FloatCbArFAMAS.isChecked() && name.contains("FAMAS")) {
            mTextPaint.setColor(Color.argb(255, 250, 255, 117));
            return "FAMAS";
        }
        //SP
        else if (BaseFloat.binding.FloatCbSrKar98k.isChecked() && name.contains("Kar98k")) {
            mTextPaint.setColor(Color.argb(255, 128, 255, 82));
            return "Kar98k";
        } else if (BaseFloat.binding.FloatCbSrM24.isChecked() && name.contains("M24")) {
            mTextPaint.setColor(Color.argb(255, 128, 255, 82));
            return "M24";
        } else if (BaseFloat.binding.FloatCbSrAWM.isChecked() && name.contains("AWM")) {
            mTextPaint.setColor(Color.argb(255, 128, 255, 82));
            return "AWM";
        } else if (BaseFloat.binding.FloatCbSrWin94.isChecked() && name.contains("Win94")) {
            mTextPaint.setColor(Color.argb(255, 128, 255, 82));
            return "Win94";
        } else if (BaseFloat.binding.FloatCbSrMosin.isChecked() && name.contains("Mosin")) {
            mTextPaint.setColor(Color.argb(255, 128, 255, 82));
            return "Mosin";
        }
        //Dmr
        else if (BaseFloat.binding.FloatCbMdrSKS.isChecked() && name.contains("SKS")) {
            mTextPaint.setColor(Color.argb(255, 82, 255, 163));
            return "SKS";
        } else if (BaseFloat.binding.FloatCbMdrVSS.isChecked() && name.contains("VSS")) {
            mTextPaint.setColor(Color.argb(255, 82, 255, 163));
            return "VSS";
        } else if (BaseFloat.binding.FloatCbMdrMini14.isChecked() && name.contains("Mini14")) {
            mTextPaint.setColor(Color.argb(255, 82, 255, 163));
            return "Mini14";
        } else if (BaseFloat.binding.FloatCbMdrMk14.isChecked() && name.contains("Mk14")) {
            mTextPaint.setColor(Color.argb(255, 82, 255, 163));
            return "Mk14";
        } else if (BaseFloat.binding.FloatCbMdrSLR.isChecked() && name.contains("SLR")) {
            mTextPaint.setColor(Color.argb(255, 82, 255, 163));
            return "SLR";
        } else if (BaseFloat.binding.FloatCbArQBZ.isChecked() && name.contains("QBZ")) {
            mTextPaint.setColor(Color.argb(255, 82, 255, 163));
            return "QBZ";
        } else if (BaseFloat.binding.FloatCbMdrMk12.isChecked() && name.contains("Mk12")) {
            mTextPaint.setColor(Color.argb(255, 82, 255, 163));
            return "Mk12";
        }
        //Smg
        else if (BaseFloat.binding.FloatCbSmgUZI.isChecked() && name.contains("Uzi")) {
            mTextPaint.setColor(Color.argb(255, 255, 166, 82));
            return "Uzi";
        } else if (BaseFloat.binding.FloatCbSmgUMP45.isChecked() && name.contains("UMP9")) {
            mTextPaint.setColor(Color.argb(255, 255, 166, 82));
            return "UMP9";
        } else if (BaseFloat.binding.FloatCbSmgVector.isChecked() && name.contains("Vector")) {
            mTextPaint.setColor(Color.argb(255, 255, 166, 82));
            return "Vector";
        } else if (BaseFloat.binding.FloatCbSmgThompson.isChecked() && name.contains("TommyGun")) {
            mTextPaint.setColor(Color.argb(255, 255, 166, 82));
            return "TommyGun";
        } else if (BaseFloat.binding.FloatCbSmgBizon.isChecked() && name.contains("PP19")) {
            mTextPaint.setColor(Color.argb(255, 255, 166, 82));
            return "PP19";
        } else if (BaseFloat.binding.FloatCbSmgMP5K.isChecked() && name.contains("MP5k")) {
            mTextPaint.setColor(Color.argb(255, 255, 166, 82));
            return "MP5k";
        } else if (BaseFloat.binding.FloatCbSmgP90.isChecked() && name.contains("P90")) {
            mTextPaint.setColor(Color.argb(255, 255, 166, 82));
            return "P90";
        }
        //Shotgun
        else if (BaseFloat.binding.FloatCbShotgunS686.isChecked() && name.contains("S686")) {
            mTextPaint.setColor(Color.argb(255, 191, 133, 78));
            return "S686";
        } else if (BaseFloat.binding.FloatCbShotgunS1897.isChecked() && name.contains("S1897")) {
            mTextPaint.setColor(Color.argb(255, 191, 133, 78));
            return "S1897";
        } else if (BaseFloat.binding.FloatCbShotgunS12k.isChecked() && name.contains("S12k")) {
            mTextPaint.setColor(Color.argb(255, 191, 133, 78));
            return "S12k";
        } else if (BaseFloat.binding.FloatCbShotgunDBS.isChecked() && name.contains("DP12")) {
            mTextPaint.setColor(Color.argb(255, 191, 133, 78));
            return "DP12";
        } else if (BaseFloat.binding.FloatCbShotgunM1014.isChecked() && name.contains("M1014")) {
            mTextPaint.setColor(Color.argb(255, 191, 133, 78));
            return "M1014";
        }
        //Lmg
        else if (BaseFloat.binding.FloatCbLmgM249.isChecked() && name.contains("M249")) {
            mTextPaint.setColor(Color.argb(255, 78, 191, 185));
            return "M249";
        } else if (BaseFloat.binding.FloatCbLmgDP28.isChecked() && name.contains("DP28")) {
            mTextPaint.setColor(Color.argb(255, 78, 191, 185));
            return "DP28";
        } else if (BaseFloat.binding.FloatCbLmgM163.isChecked() && name.contains("MG3")) {
            mTextPaint.setColor(Color.argb(255, 78, 191, 185));
            return "M163";
        }
        //Scope
        else if (BaseFloat.binding.FloatCbScopeX8.isChecked() && name.contains("8X")) {
            mTextPaint.setColor(Color.argb(255, 167, 78, 191));
            return "x8";
        } else if (BaseFloat.binding.FloatCbScopeX6.isChecked() && name.contains("6X")) {
            mTextPaint.setColor(Color.argb(255, 167, 78, 191));
            return "x6";
        } else if (BaseFloat.binding.FloatCbScopeX4.isChecked() && name.contains("4X")) {
            mTextPaint.setColor(Color.argb(255, 167, 78, 191));
            return "x4";
        } else if (BaseFloat.binding.FloatCbScopeX3.isChecked() && name.contains("3X")) {
            mTextPaint.setColor(Color.argb(255, 167, 78, 191));
            return "x3";
        } else if (BaseFloat.binding.FloatCbScopeX2.isChecked() && name.contains("2X")) {
            mTextPaint.setColor(Color.argb(255, 167, 78, 191));
            return "x2";
        } else if (BaseFloat.binding.FloatCbScopeRedPoint.isChecked() && name.contains("MZJ_HD")) {
            mTextPaint.setColor(Color.argb(255, 167, 78, 191));
            return "RedDot";
        }
        //Melee
        else if (BaseFloat.binding.FloatCbPistolSickle.isChecked() && name.contains("Sickle")) {
            mTextPaint.setColor(Color.argb(255, 209, 113, 155));
            return "Sickle";
        } else if (BaseFloat.binding.FloatCbMeleePan.isChecked() && name.contains("Pan")) {
            mTextPaint.setColor(Color.argb(255, 209, 113, 155));
            return "Pan";
        } else if (BaseFloat.binding.FloatCbMeleeCrowbar.isChecked() && name.contains("Cowbar")) {
            mTextPaint.setColor(Color.argb(255, 209, 113, 155));
            return "Crowbar";
        } else if (BaseFloat.binding.FloatCbMeleeMachete.isChecked() && name.contains("Machete")) {
            mTextPaint.setColor(Color.argb(255, 209, 113, 155));
            return "Machete";
        }
        //Other
        else if (BaseFloat.binding.FloatCbOtherCrossbow.isChecked() && name.contains("Crossbow")) {
            mTextPaint.setColor(Color.argb(255, 209, 113, 155));
            return "Crossbow";
        }
        //Helmet
        else if (BaseFloat.binding.FloatCbHelmetLv1.isChecked() && name.contains("Helmet_Lv1")) {
            mTextPaint.setColor(Color.argb(255, 96, 156, 189));
            return "Helmet_1";
        } else if (BaseFloat.binding.FloatCbHelmetLv2.isChecked() && name.contains("Helmet_Lv2")) {
            mTextPaint.setColor(Color.argb(255, 96, 156, 189));
            return "Helmet_2";
        } else if (BaseFloat.binding.FloatCbHelmetLv3.isChecked() && name.contains("Helmet_Lv3")) {
            mTextPaint.setColor(Color.argb(255, 96, 156, 189));
            return "Helmet_3";
        }
        //Armor
        else if (BaseFloat.binding.FloatCbArmorLv1.isChecked() && name.contains("Armor_Lv1")) {
            mTextPaint.setColor(Color.argb(255, 96, 189, 121));
            return "Armor_1";
        } else if (BaseFloat.binding.FloatCbArmorLv2.isChecked() && name.contains("Armor_Lv2")) {
            mTextPaint.setColor(Color.argb(255, 96, 189, 121));
            return "Armor_2";
        } else if (BaseFloat.binding.FloatCbArmorLv3.isChecked() && name.contains("Armor_Lv3")) {
            mTextPaint.setColor(Color.argb(255, 96, 189, 121));
            return "Armor_3";
        }
        //BackPack
        else if (BaseFloat.binding.FloatCbBackpackLv1.isChecked() && name.contains("Bag_Lv1")) {
            mTextPaint.setColor(Color.argb(255, 135, 96, 189));
            return "Bag_1";
        } else if (BaseFloat.binding.FloatCbBackpackLv2.isChecked() && name.contains("Bag_Lv2")) {
            mTextPaint.setColor(Color.argb(255, 135, 96, 189));
            return "Bag_2";
        } else if (BaseFloat.binding.FloatCbBackpackLv3.isChecked() && name.contains("Bag_Lv3")) {
            mTextPaint.setColor(Color.argb(255, 135, 96, 189));
            return "Bag_3";
        }
        //Mad kit
        else if (BaseFloat.binding.FloatCbMadKitEnergy.isChecked() && name.contains("Drink")) {
            mTextPaint.setColor(Color.argb(255, 255, 82, 82));
            return "Energy";
        } else if (BaseFloat.binding.FloatCbMadKitPainkiller.isChecked() && name.contains("Pills")) {
            mTextPaint.setColor(Color.argb(255, 255, 82, 82));
            return "Painkiller";
        } else if (BaseFloat.binding.FloatCbMadKitFuel.isChecked() && name.contains("Destructible")) {
            mTextPaint.setColor(Color.argb(255, 255, 82, 82));
            return "Fuel";
        } else if (BaseFloat.binding.FloatCbMadKitAdrenaline.isChecked() && name.contains("Injection")) {
            mTextPaint.setColor(Color.argb(255, 255, 82, 82));
            return "Adrenaline";
        } else if (BaseFloat.binding.FloatCbMadKitFirst.isChecked() && name.contains("Firstaid")) {
            mTextPaint.setColor(Color.argb(255, 255, 82, 82));
            return "First";
        } else if (BaseFloat.binding.FloatCbMadKitMadKit.isChecked() && name.contains("FirstAidbox")) {
            mTextPaint.setColor(Color.argb(255, 255, 82, 82));
            return "MadKit";
        }
        //Muzzle
        else if (BaseFloat.binding.FloatCbMuzzleVertical.isChecked() && name.contains("Vertical")) {
            mTextPaint.setColor(Color.argb(255, 156, 101, 111));
            return "Vertical";
        } else if (BaseFloat.binding.FloatCbMuzzleCompensator.isChecked() && name.contains("QK_Large")) {
            mTextPaint.setColor(Color.argb(255, 156, 101, 111));
            return "Compensator";
        } else if (BaseFloat.binding.FloatCbMuzzleEQAr.isChecked() && name.contains("DJ_Large_EQ")) {
            mTextPaint.setColor(Color.argb(255, 156, 101, 111));
            return "AR_EQ";
        } else if (BaseFloat.binding.FloatCbMuzzleEAr.isChecked() && name.contains("DJ_Large_E")) {
            mTextPaint.setColor(Color.argb(255, 156, 101, 111));
            return "AR_E";
        } else if (BaseFloat.binding.FloatCbMuzzleESmg.isChecked() && name.contains("DJ_Mid_E")) {
            mTextPaint.setColor(Color.argb(255, 156, 101, 111));
            return "SMG_E";
        } else if (BaseFloat.binding.FloatCbMuzzleEQSmg.isChecked() && name.contains("DJ_Mid_EQ")) {
            mTextPaint.setColor(Color.argb(255, 156, 101, 111));
            return "SMG_EQ";
        } else if (BaseFloat.binding.FloatCbMuzzleESp.isChecked() && name.contains("DJ_Sniper_E")) {
            mTextPaint.setColor(Color.argb(255, 156, 101, 111));
            return "SNIPER_E";
        } else if (BaseFloat.binding.FloatCbMuzzleEQSp.isChecked() && name.contains("DJ_Sniper_EQ")) {
            mTextPaint.setColor(Color.argb(255, 156, 101, 111));
            return "SNIPER_EQ";
        } else if (BaseFloat.binding.FloatCbVehicleBicycle.isChecked() && name.contains("Bike")) {
            return "Bicycle";
        }
        //item
        else if (BaseFloat.binding.FloatCbItemDrop.isChecked() && name.contains("PlayerDeadInventoryBox_C")) {
            mTextPaint.setColor(Color.argb(255, 214, 214, 214));
            return "AirDropBox";
        } else if (BaseFloat.binding.FloatCbItemBox.isChecked() && name.contains("PickUpListWrapperActor")) {
            mTextPaint.setColor(Color.argb(255, 214, 214, 214));
            return "Box";
        } else if (BaseFloat.binding.FloatCbItemFlareGun.isChecked() && name.contains("Flaregun")) {
            mTextPaint.setColor(Color.argb(255, 185, 243, 43));
            return "Flaregun";
        } else if (BaseFloat.binding.FloatCbItemCoins.isChecked() && name.contains("GoldenToken")) {
            mTextPaint.setColor(Color.argb(255, 20, 255, 20));
            return "$1";
        } else {
            return null;
        }
    }

    private String GetWeapon(int id) {
        //AR and SMG
        if (id == 101006) return "AUG";
        if (id == 101008) return "M7";
        if (id == 101003) return "SCAR";
        if (id == 101004) return "M4";
        if (id == 101002) return "M16";
        if (id == 101009) return "Mk47";
        if (id == 101010) return "G36C";
        if (id == 101007) return "QBZ";
        if (id == 101001) return "AKM";
        if (id == 101005) return "Groza";
        if (id == 102005) return "Bizon";
        if (id == 102004) return "Tommy";
        if (id == 102007) return "MP5";
        if (id == 102002) return "UMP";
        if (id == 102003) return "Vector";
        if (id == 102001) return "Uzi";
        if (id == 105002) return "DP";
        if (id == 105001) return "Bkcy";
        //Snipers
        if (id == 103003) return "AWM";
        if (id == 103010) return "QBU";
        if (id == 103009) return "SLR";
        if (id == 103004) return "SKS";
        if (id == 103006) return "Mini";
        if (id == 103002) return "M24";
        if (id == 103001) return "Kar";
        if (id == 103005) return "VSS";
        if (id == 103008) return "Win";
        if (id == 103007) return "Mk14";
        //Shotguns and Hand weapons
        if (id == 104003) return "S12K";
        if (id == 104004) return "DBS";
        if (id == 104001) return "S686";
        if (id == 104002) return "S1897";
        if (id == 108003) return "Sickle";
        if (id == 108001) return "Machete";
        if (id == 108002) return "Crowbar";
        if (id == 107001) return "CrossBow";
        if (id == 108004) return "Pan";
        //Pistols
        if (id == 106006) return "SawedOff";
        if (id == 106003) return "R1895";
        if (id == 106008) return "Vz61";
        if (id == 106001) return "P92";
        if (id == 106004) return "P18C";
        if (id == 106005) return "R45";
        if (id == 106002) return "P1911";
        if (id == 106010) return "DesertEagle";
        return null;
    }

}