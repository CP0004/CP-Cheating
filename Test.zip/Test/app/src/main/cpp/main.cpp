#include <sys/types.h>
#include <pthread.h>
#include <jni.h>
#include <string>
#include "obfuscate.h"
#include "ESP.h"
#include "Hacks.h"

#define  LOG_TAG    "C_LANG"
#define  LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern "C" JNIEXPORT void JNICALL
Java_com_test_jo_draw_Overlay_DrawOn(JNIEnv *env, jclass, jobject espView, jobject canvas) {
    if (isVIP) {
        ESP espOverlay = ESP(env, espView, canvas);
        if (espOverlay.isValid()) {
            if (!isFixTouch) {
                system("su -c settings put global block_untrusted_touches 0");
                isFixTouch = true;
            }
            DrawESP(espOverlay, espOverlay.getWidth(), espOverlay.getHeight());
        }
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_test_jo_draw_Overlay_Close(JNIEnv *, jobject) {
    Close();
}

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_test_jo_tool_Tools_SecurityBool(JNIEnv *env, jclass clazz, jfloat key) {
    key = key + 0.010f;
    if (key == 1.020f) {
        return true;
    } else {
        return false;
    }
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_test_jo_tool_Tools_Rights(JNIEnv *env, jclass thiz, jint index) {
    switch ((int) index) {
        case static_cast<int>(DataControl::EMAIL):
            return env->NewStringUTF(email);
        case static_cast<int>(DataControl::ID_BASE):
            return env->NewStringUTF(id_Base);
        case static_cast<int>(DataControl::TELEGRAM):
            return env->NewStringUTF(telegram);
        case static_cast<int>(DataControl::TIKTOK):
            return env->NewStringUTF(tiktok);
        case static_cast<int>(DataControl::KEY_PRIVATE_CPP):
            return env->NewStringUTF(key_Private_Cpp);
        case static_cast<int>(DataControl::KEY_PUBLIC_CPP):
            return env->NewStringUTF(key_Public_Cpp);
        case static_cast<int>(DataControl::PATH):
            return env->NewStringUTF(path);
        case static_cast<int>(DataControl::_NULL):
            return env->NewStringUTF(_Null);
    }
    return env->NewStringUTF(_Null);
}
//DataControl dataControl = DataControl();
extern "C"
JNIEXPORT void JNICALL
Java_com_test_jo_tool_Tools_LinkValue(JNIEnv *env, jclass clazz, jint index, jint value,
                                      jboolean i_check) {
    if (isVIP) {
        switch ((int) index) {
            //-- Drawing For Player
            case static_cast<int>(DataControl::LINE):
                isLine = i_check;
                break;
            case static_cast<int>(DataControl::SKELETON):
                isSkeleton = i_check;
                break;
            case static_cast<int>(DataControl::INFO_PLAYER):
                isInfoPlayer = i_check;
                break;
            case static_cast<int>(DataControl::WEAPON):
                isWeapon = i_check;
                break;
            case static_cast<int>(DataControl::MARK):
                isMark = i_check;
                break;
            case static_cast<int>(DataControl::HEALTH):
                isHealth = i_check;
                break;
            case static_cast<int>(DataControl::GRENADE):
                isGrenade = i_check;
                break;
            case static_cast<int>(DataControl::BOX):
                isBox = i_check;
                break;
            case static_cast<int>(DataControl::DIST):
                isDist = i_check;
                break;
                //-- Memory
            case static_cast<int>(DataControl::LESS):
                isLess = i_check;
                break;
            case static_cast<int>(DataControl::CROSS_HAIR):
                isCrossHire = i_check;
                break;
            case static_cast<int>(DataControl::AIMBOT):
                isAimBot = i_check;
                break;
            case static_cast<int>(DataControl::BULLET):
                isBullet = i_check;
                break;
            case static_cast<int>(DataControl::BOT):
                isBot = i_check;
                break;
            case static_cast<int>(DataControl::KNOCK):
                isKnock = i_check;
                break;
            case static_cast<int>(DataControl::IPAD_VIEW):
                rangeIPadView = value + 90;
                break;
            case static_cast<int>(DataControl::DIST_BULLET):
                distBullet = value;
                break;
            case static_cast<int>(DataControl::FOV_BULLET):
                fovBullet = value;
                break;
            case static_cast<int>(DataControl::TARGET_MODE):
                targetMode = value;
                break;
                //-- Controls
            case static_cast<int>(DataControl::WIDTH_LINE):
                widthLine = (float) ((float) value - 0.9f);
                break;
            case static_cast<int>(DataControl::RADIUS360):
                radiusAfter360 = value;
                break;
            case static_cast<int>(DataControl::SIZE_ITEM):
                sizeItem = value;
                break;
            case static_cast<int>(DataControl::SIZE_VEHICLE):
                sizeVehicle = value;
                break;
            case static_cast<int>(DataControl::SIZE_INFO):
                sizeInfo = value;
                break;
            case static_cast<int>(DataControl::UP_INFO):
                upInfo = value;
                break;
                //-- Other
            case static_cast<int>(DataControl::HIDE_ITEMS):
                isHideItem = i_check;
                break;
            default:
                break;
        }
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_test_jo_draw_Overlay_getReady(JNIEnv *, jobject thiz) {
    if (isVIP) {
        int sockCheck = 1;

        if (!Create()) {
            perror("Creation failed");
            return false;
        }
        setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &sockCheck, sizeof(int));
        if (!Bind()) {
            perror("Bind failed");
            return false;
        }

        if (!Listen()) {
            perror("Listen failed");
            return false;
        }
        if (Accept()) {
            return true;
        }
    }
    return false;
}

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_test_jo_tool_Tools_CheckKeyCPP(JNIEnv *env, jclass clazz, jlong keyPrivate,
                                        jlong keyPublic) {
    if (keyPrivate == PidPrivate && keyPublic == PidPublic) {
        isVIP = true;
        return true;
    } else {
        isVIP = false;
        return false;
    }
}
extern "C"
JNIEXPORT void JNICALL
Java_com_test_jo_tool_Tools_SetDataServer(JNIEnv *env, jclass clazz, jboolean memory_mode,
                                          jfloat version_app) {
    memoryModes = memory_mode;
    versionApp = version_app;
}

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_test_jo_tool_Tools_CheckMemory(JNIEnv *env, jclass clazz) {
    return memoryModes;
}
extern "C"
JNIEXPORT jboolean JNICALL
Java_com_test_jo_tool_Tools_CheckVip(JNIEnv *env, jclass clazz) {
    return isVIP;
}

extern "C"
JNIEXPORT jfloat JNICALL
Java_com_test_jo_tool_Tools_CheckVersionApp(JNIEnv *env, jclass clazz) {
    return versionApp;
}
