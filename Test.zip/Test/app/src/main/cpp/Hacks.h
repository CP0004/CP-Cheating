#ifndef DESI_ESP_IMPORTANT_HACKS_H
#define DESI_ESP_IMPORTANT_HACKS_H

#include "socket.h"

Request request;
Response response;

float x, y;
char extra[30];
int botCount, playerCount, knockCount;
Color colorPlayer, colorText, clrHealth;

void DrawESP(ESP esp, int screenWidth, int screenHeight) {

    if (isVIP) {
        botCount = 0;
        playerCount = 0;
        knockCount = 0;
        request.ScreenHeight = screenHeight;
        request.ScreenWidth = screenWidth;
        request.memory.isLess = isLess;
        request.memory.isAimbot = isAimBot;
        request.memory.isIPadView = rangeIPadView;
        request.memory.DistBullet = distBullet;
        request.memory.FovBullet = fovBullet;
        request.memory.TargetMode = targetMode;
        request.memory.isCrosshair = isCrossHire;
        request.memory.isBulletTrack = isBullet;
        request.memory.isBot = isBot;
        request.memory.isKnock = isKnock;
        //-- Other
        request.Vip = isVIP;

        send((void *) &request, sizeof(request));
        receive((void *) &response);
    }

    //--===== Check Player Lobby =====
    if (!response.InLobby) {
        if (response.Success) {
            for (int i = 0; i < response.PlayerCount; i++) {
                //--
                x = response.Players[i].HeadLocation.x;
                y = response.Players[i].HeadLocation.y;

                if (response.Players[i].isBot && response.Players[i].Health <= 0) {
                    colorPlayer = Color(255, 255, 255, 255);
                    colorText = Color(255, 255, 255, 255);
                }

                if (response.Players[i].isBot && response.Players[i].Health > 0) {
                    botCount++;
                    colorPlayer = Color(255, 255, 255, 255);
                    colorText = Color(255, 255, 255, 255);
                }

                if (!response.Players[i].isBot && response.Players[i].Health > 0) {
                    playerCount++;
                    colorPlayer = Color(232, 0, 12, 255);
                    colorText = Color(255, 255, 255, 255);
                }

                if (!response.Players[i].isBot && response.Players[i].Health <= 0) {
                    knockCount++;
                    colorPlayer = Color(0, 255, 0, 255);
                    colorText = Color(0, 255, 0, 255);
                }

                if (response.Players[i].isInAim)
                    colorPlayer = Color(255, 255, 0, 255);

                float magic_number = (response.Players[i].Distance * response.fov);
                float mx = (screenWidth / 4) / magic_number;
                float my = (screenWidth / 1.38) / magic_number;
                float top = y - my + (screenWidth / 1.7) / magic_number;
                float bottom = y + my + screenHeight / 4 / magic_number;

                if (response.Players[i].HeadLocation.z != 1) {

                    if (x > -50 && x < screenWidth + 50) {
                        if (isSkeleton && response.Players[i].Bone.isBone) {
                            esp.DrawLine(colorPlayer, widthLine, Vec2(x, y),
                                         Vec2(response.Players[i].Bone.neck.x,
                                              response.Players[i].Bone.neck.y));
                            esp.DrawLine(colorPlayer, widthLine,
                                         Vec2(response.Players[i].Bone.neck.x,
                                              response.Players[i].Bone.neck.y),
                                         Vec2(response.Players[i].Bone.cheast.x,
                                              response.Players[i].Bone.cheast.y));
                            esp.DrawLine(colorPlayer, widthLine,
                                         Vec2(response.Players[i].Bone.cheast.x,
                                              response.Players[i].Bone.cheast.y),
                                         Vec2(response.Players[i].Bone.pelvis.x,
                                              response.Players[i].Bone.pelvis.y));
                            esp.DrawLine(colorPlayer, widthLine,
                                         Vec2(response.Players[i].Bone.neck.x,
                                              response.Players[i].Bone.neck.y),
                                         Vec2(response.Players[i].Bone.lSh.x,
                                              response.Players[i].Bone.lSh.y));
                            esp.DrawLine(colorPlayer, widthLine,
                                         Vec2(response.Players[i].Bone.neck.x,
                                              response.Players[i].Bone.neck.y),
                                         Vec2(response.Players[i].Bone.rSh.x,
                                              response.Players[i].Bone.rSh.y));
                            esp.DrawLine(colorPlayer, widthLine,
                                         Vec2(response.Players[i].Bone.lSh.x,
                                              response.Players[i].Bone.lSh.y),
                                         Vec2(response.Players[i].Bone.lElb.x,
                                              response.Players[i].Bone.lElb.y));
                            esp.DrawLine(colorPlayer, widthLine,
                                         Vec2(response.Players[i].Bone.rSh.x,
                                              response.Players[i].Bone.rSh.y),
                                         Vec2(response.Players[i].Bone.rElb.x,
                                              response.Players[i].Bone.rElb.y));
                            esp.DrawLine(colorPlayer, widthLine,
                                         Vec2(response.Players[i].Bone.lElb.x,
                                              response.Players[i].Bone.lElb.y),
                                         Vec2(response.Players[i].Bone.lWr.x,
                                              response.Players[i].Bone.lWr.y));
                            esp.DrawLine(colorPlayer, widthLine,
                                         Vec2(response.Players[i].Bone.rElb.x,
                                              response.Players[i].Bone.rElb.y),
                                         Vec2(response.Players[i].Bone.rWr.x,
                                              response.Players[i].Bone.rWr.y));
                            esp.DrawLine(colorPlayer, widthLine,
                                         Vec2(response.Players[i].Bone.pelvis.x,
                                              response.Players[i].Bone.pelvis.y),
                                         Vec2(response.Players[i].Bone.lTh.x,
                                              response.Players[i].Bone.lTh.y));
                            esp.DrawLine(colorPlayer, widthLine,
                                         Vec2(response.Players[i].Bone.pelvis.x,
                                              response.Players[i].Bone.pelvis.y),
                                         Vec2(response.Players[i].Bone.rTh.x,
                                              response.Players[i].Bone.rTh.y));
                            esp.DrawLine(colorPlayer, widthLine,
                                         Vec2(response.Players[i].Bone.lTh.x,
                                              response.Players[i].Bone.lTh.y),
                                         Vec2(response.Players[i].Bone.lKn.x,
                                              response.Players[i].Bone.lKn.y));
                            esp.DrawLine(colorPlayer, widthLine,
                                         Vec2(response.Players[i].Bone.rTh.x,
                                              response.Players[i].Bone.rTh.y),
                                         Vec2(response.Players[i].Bone.rKn.x,
                                              response.Players[i].Bone.rKn.y));
                            esp.DrawLine(colorPlayer, widthLine,
                                         Vec2(response.Players[i].Bone.lKn.x,
                                              response.Players[i].Bone.lKn.y),
                                         Vec2(response.Players[i].Bone.lAn.x,
                                              response.Players[i].Bone.lAn.y));
                            esp.DrawLine(colorPlayer, widthLine,
                                         Vec2(response.Players[i].Bone.rKn.x,
                                              response.Players[i].Bone.rKn.y),
                                         Vec2(response.Players[i].Bone.rAn.x,
                                              response.Players[i].Bone.rAn.y));
                        }

                        if (isSkeleton) {
                            esp.DrawCircle(colorPlayer,
                                           Vec2(response.Players[i].HeadLocation.x,
                                                response.Players[i].HeadLocation.y),
                                           screenHeight / 6.5f / magic_number, widthLine);
                        }

                        if (isBox)
                            esp.DrawRect(colorPlayer,
                                         widthLine, Vec2(x - mx, top),
                                         Vec2(x + mx, bottom));


                        if (isHealth) {
                            if (response.Players[i].Health <= 0) {
                                esp.DrawText(colorText, "KNOCK",
                                             Vec2(x, top - screenHeight / 225), 12);
                            } else {
                                float nameLength =
                                        size(response.Players[i].PlayerNameByte) * 1.4;
                                float healthLength = screenWidth / 70;
                                if (healthLength < mx) {
                                    healthLength = mx;
                                }
                                if (response.Players[i].Health < 25) {
                                    clrHealth = Color(255, 0, 0, 120);
                                } else if (response.Players[i].Health < 50) {
                                    clrHealth = Color(255, 165, 0, 120);
                                } else if (response.Players[i].Health < 75) {
                                    clrHealth = Color(255, 255, 0, 120);
                                } else {
                                    clrHealth = Color(25, 171, 64, 120);
                                }
                                esp.DrawFilledRect(clrHealth,
                                                   Vec2(x - (healthLength +
                                                             (nameLength + (sizeInfo * 7))),
                                                        top -
                                                        ((screenHeight /
                                                          (14 -
                                                           (sizeInfo /
                                                            7.5))) +
                                                         (upInfo))),
                                                   Vec2(x - (healthLength +
                                                             (nameLength + (sizeInfo * 7))) +
                                                        (2 * (healthLength +
                                                              (nameLength + (sizeInfo * 7)))) *
                                                        response.Players[i].Health / 100,
                                                        top -
                                                        ((screenHeight /
                                                          (26 -
                                                           (sizeInfo /
                                                            7.5))) +
                                                         (upInfo))));

                                esp.DrawRect(Color(0, 0, 0), screenHeight / 660,
                                             Vec2(x - (healthLength +
                                                       (nameLength + (sizeInfo * 7))), top -
                                                                                       ((screenHeight /
                                                                                         (14 -
                                                                                          (sizeInfo /
                                                                                           7.5))) +
                                                                                        (upInfo))),
                                             Vec2(x + (healthLength +
                                                       (nameLength + (sizeInfo * 7))), top -
                                                                                       ((screenHeight /
                                                                                         (26 -
                                                                                          (sizeInfo /
                                                                                           7.5))) +
                                                                                        (upInfo))));
                            }
                        }

                        //-- Name and TeamId and Flag ================
                        if (isInfoPlayer) {
                            if (response.Players[i].Health <= 0) {
                                // nul
                            } else {
                                if (response.Players[i].isBot) {
                                    // null
                                    esp.DrawText(colorText, "Bot",
                                                 Vec2(x, top - ((screenHeight /
                                                                 (21 - (sizeInfo / 7.5))) +
                                                                (upInfo))),
                                                 (15 + sizeInfo));
                                } else {
                                    esp.InfoPLayer(colorText, response.Players[i].TeamID,
                                                   response.Players[i].PlayerNameByte,
                                                   response.Players[i].PlayerNationByte,
                                                   Vec2(x, top - ((screenHeight /
                                                                   (21 - (sizeInfo / 7.5))) +
                                                                  (upInfo))),
                                                   (15 + sizeInfo));
                                }
                            }
                        }

                        //-- Dist ================
                        if (isDist) {
                            if (response.Players[i].Health <= 0) {
                                // nul
                            } else {
                                sprintf(extra, "%0.0fM", response.Players[i].Distance);
                                esp.DrawText(Color(240, 210, 0), extra,
                                             Vec2(x, top + -screenHeight / 90), 22);
                            }
                        }

                        // weapon
                        if (isWeapon && response.Players[i].Weapon.isWeapon)
                            esp.DrawWeapon(Color(240, 210, 0), response.Players[i].Weapon.id,
                                           response.Players[i].Weapon.ammo,
                                           Vec2(x, bottom + 25), 22);

                        //--
                    }

                }

                //-- Alert 360 ================
                if (response.Players[i].HeadLocation.z == 1.0f) {
                    if (!isMark)
                        continue;
                    if (x > screenWidth - screenWidth / 12)
                        x = screenWidth - screenWidth / 120;
                    else if (x < screenWidth / 120)
                        x = screenWidth / 12;
                    if (y < screenHeight / 1) { // top
                        esp.DrawFilledCircle(colorPlayer,
                                             Vec2(x,
                                                  screenHeight -
                                                  (offsetAfter360 + radiusAfter360)),
                                             offsetAfter360 + radiusAfter360);
                    } else {
                        esp.DrawFilledCircle(colorPlayer,
                                             Vec2(x, 0 + (offsetAfter360 + radiusAfter360)),
                                             offsetAfter360 + radiusAfter360);
                    }
                } else if (x < -screenWidth / 10 || x > screenWidth + screenWidth / 10) {
                    if (!isMark)
                        continue;
                    if (y > screenHeight - screenHeight / 12)
                        y = screenHeight - screenHeight / 120;
                    else if (y < screenHeight / 120)
                        y = screenHeight / 12;
                    if (x > screenWidth / 2) {
                        esp.DrawFilledCircle(colorPlayer,
                                             Vec2(screenWidth -
                                                  (offsetAfter360 + radiusAfter360),
                                                  y),
                                             offsetAfter360 + radiusAfter360);
                    } else {
                        esp.DrawFilledCircle(colorPlayer,
                                             Vec2(0 + (offsetAfter360 + radiusAfter360), y),
                                             offsetAfter360 + radiusAfter360);
                    }
                } else if (y < -screenHeight / 10 || y > screenHeight + screenHeight / 10) {
                    if (!isMark)
                        continue;
                    if (x > screenWidth - screenWidth / 12)
                        x = screenWidth - screenWidth / 120;
                    else if (x < screenWidth / 120)
                        x = screenWidth / 12;
                    if (y > screenHeight / 2.5) {
                        esp.DrawFilledCircle(colorPlayer,
                                             Vec2(x,
                                                  screenHeight -
                                                  (offsetAfter360 + radiusAfter360)),
                                             offsetAfter360 + radiusAfter360);
                    } else {
                        esp.DrawFilledCircle(colorPlayer,
                                             Vec2(x, 0 + (offsetAfter360 + radiusAfter360)),
                                             offsetAfter360 + radiusAfter360);
                    }
                } else if (isLine) {
                    if (!response.Players[i].isBot && response.Players[i].Health > 0) {
                        esp.DrawLine(colorPlayer, 0.5 + (widthLine / 2),
                                     Vec2(screenWidth / 2, 180), Vec2(x, top));
                    }
                }
            }

            if (botCount + playerCount > 0) {

                sprintf(extra, "%d", botCount);
                esp.DrawText(Color(255, 255, 255), "BOT",
                             Vec2(screenWidth / 2 - 60, 100), 31);

                esp.DrawText(Color(255, 255, 255), extra,
                             Vec2(screenWidth / 2 - 60, 150), 35);

                sprintf(extra, "%d", playerCount);
                esp.DrawText(Color(232, 0, 12), "PLAYER",
                             Vec2(screenWidth / 2 + 60, 100), 31);

                esp.DrawText(Color(232, 0, 12), extra,
                             Vec2(screenWidth / 2 + 60, 150), 35);

                esp.DrawText(Color(255, 255, 255), "﹀",
                             Vec2(screenWidth / 2, 185), 45);
                esp.DrawText(Color(255, 255, 255), "____    ____",
                             Vec2(screenWidth / 2, 160), 45);
            }

            if (knockCount > 0) {
                sprintf(extra, "KNOCK : %d", knockCount);
                esp.DrawText(Color(0, 255, 0), extra,
                             Vec2(screenWidth / 2, 350), 30);
            }

            //--==== IS Grenade ===============================================================
            for (int i = 0; i < response.GrenadeCount; i++) {
                if (!isGrenade)
                    continue;
                esp.DrawText(Color(255, 0, 0), "Warning Grenade !!!",
                             Vec2(screenWidth / 2, 300), 30);
                if (response.Grenade[i].Location.z != 1.0f) {
                    if (response.Grenade[i].type == 1) {
                        esp.DrawFilledCircle(Color(255, 0, 0, 255),
                                             Vec2(response.Grenade[i].Location.x,
                                                  response.Grenade[i].Location.y),
                                             20);
                        sprintf(extra, "%0.0f", response.Grenade[i].Distance);
                        esp.DrawText(Color(255, 255, 255, 150), extra,
                                     Vec2(response.Grenade[i].Location.x,
                                          response.Grenade[i].Location.y + 5),
                                     16);
                    } else if (response.Grenade[i].type == 2) {
                        esp.DrawFilledCircle(Color(255, 140, 0, 255),
                                             Vec2(response.Grenade[i].Location.x,
                                                  response.Grenade[i].Location.y),
                                             20);
                        sprintf(extra, "%0.0f", response.Grenade[i].Distance);
                        esp.DrawText(Color(255, 255, 255, 150), extra,
                                     Vec2(response.Grenade[i].Location.x,
                                          response.Grenade[i].Location.y + 5),
                                     16);
                    } else if (response.Grenade[i].type == 3) {
                        esp.DrawFilledCircle(Color(0, 255, 200, 255),
                                             Vec2(response.Grenade[i].Location.x,
                                                  response.Grenade[i].Location.y),
                                             20);
                        sprintf(extra, "%0.0f", response.Grenade[i].Distance);
                        esp.DrawText(Color(255, 255, 255, 150), extra,
                                     Vec2(response.Grenade[i].Location.x,
                                          response.Grenade[i].Location.y + 5),
                                     16);
                    } else if (response.Grenade[i].type == 4) {
                        esp.DrawFilledCircle(Color(0, 209, 7, 255),
                                             Vec2(response.Grenade[i].Location.x,
                                                  response.Grenade[i].Location.y),
                                             20);
                        sprintf(extra, "%0.0f", response.Grenade[i].Distance);
                        esp.DrawText(Color(255, 255, 255, 150), extra,
                                     Vec2(response.Grenade[i].Location.x,
                                          response.Grenade[i].Location.y + 5),
                                     16);
                    }
                }
            }

            for (int i = 0; i < response.VehicleCount; i++) {
                if (response.Vehicles[i].Location.z != 1.0f) {
                    esp.DrawVehicles(response.Vehicles[i].VehicleName,
                                     response.Vehicles[i].Distance,
                                     Vec2(response.Vehicles[i].Location.x,
                                          response.Vehicles[i].Location.y),
                                     normalSize + sizeVehicle, 0, 0, true
                    );
                }
            }

            if (isHideItem)
                for (int i = 0; i < response.ItemsCount; i++) {
                    if (response.Items[i].Location.z != 1.0f) {
                        esp.DrawItems(response.Items[i].ItemName, response.Items[i].Distance,
                                      Vec2(response.Items[i].Location.x,
                                           response.Items[i].Location.y),
                                      normalSize + sizeItem);
                    }
                }

            // --
            if (request.memory.isBulletTrack)
                esp.DrawCircle(Color(255, 255, 255, 255), Vec2(screenWidth / 2, screenHeight / 2),
                               request.memory.FovBullet, 2.5);
        }
        //--
    } else {
        esp.DrawText(Color(255, 255, 255),
                     "In Lobby",
                     Vec2(screenWidth
                          / 2, 100), 30);
    }

}

#endif // DESI_ESP_IMPORTANT_HACKS_H
