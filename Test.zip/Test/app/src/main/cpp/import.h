#ifndef DESI_ESP_IMPORTANT_IMPORT_H
#define DESI_ESP_IMPORTANT_IMPORT_H

#include <jni.h>
#include <string>
#include <cstdlib>
#include <unistd.h>
#include <sys/mman.h>
#include <android/log.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <cerrno>
#include <sys/un.h>
#include <cstring>
#include <string>
#include <cmath>
#include "struct.h"


bool
//-- Drawing For Player
isLine = true,
        isSkeleton = true,
        isInfoPlayer = true,
        isWeapon = true,
        isMark = true,
        isHealth = true,
        isGrenade = true,
        isBox = true,
        isDist = true,
//-- Memory
isLess = true,
        isCrossHire = false,
        isAimBot = false,
        isBullet = false,
        isBot = false,
        isKnock = false,
//Other
isVIP = false,
        isHideItem = true,
        isFixTouch = false;

float
//-- Controls
widthLine = 2.0f,
        radiusAfter360 = 10.0f,
        sizeItem = 12.0f,
        sizeVehicle = 12.0f,
        sizeInfo = 0.0f,
        upInfo = 0.0f,
//-- Memory
rangeIPadView = 90.0f,
        distBullet = 70.0f,
        fovBullet = 100.0f,
        targetMode = 1.0f,
//-- Other
normalSize = 7.0f,
        offsetAfter360 = 12.0f;
long PidPrivate = 1701593463986640005;
long PidPublic = 2194111269143250798;

const char *email = "cHViZ21vYmlsZXZpcEBjcC5jb20="; //-- pubgmobilevip@cp.com
const char *id_Base = "QmFzZVNlcnZlcg=="; //-- BaseServer
const char *telegram = "aHR0cHM6Ly90Lm1lL0NQX0NoZWF0aW5n"; //-- https://t.me/CP_Cheating
const char *tiktok = "aHR0cHM6Ly93d3cudGlrdG9rLmNvbS9AY3BfZGV2ZWxvcGVy"; //-- https://www.tiktok.com/@cp_developer
const char *key_Private_Cpp = "MTcwMTU5MzQ2Mzk4NjY0MDAwNQ=="; //-- 1701593463986640005
const char *key_Public_Cpp = "MjE5NDExMTI2OTE0MzI1MDc5OA=="; //-- 2194111269143250798
const char *path = "ZGF0YS91c2VyLzAvY29tLnRlc3Quam8vc2hhcmVkX3ByZWZz"; //-- data/user/0/com.test.jo/shared_prefs
const char *_Null = "bnVsbA=="; //-- null

float versionApp;
bool memoryModes;

enum class DataControl {
    //-- Drawing For Player
    LINE,
    SKELETON,
    INFO_PLAYER,
    WEAPON,
    MARK,
    HEALTH,
    GRENADE,
    BOX,
    DIST,
    //-- MEMORY
    LESS,
    CROSS_HAIR,
    AIMBOT,
    BULLET,
    IPAD_VIEW,
    DIST_BULLET,
    FOV_BULLET,
    TARGET_MODE,
    BOT,
    KNOCK, //-- CONTROLS
    WIDTH_LINE,
    RADIUS360,
    SIZE_ITEM,
    SIZE_VEHICLE,
    SIZE_INFO,
    UP_INFO, //-- RIGHTS
    EMAIL,
    ID_BASE,
    TELEGRAM,
    TIKTOK,
    KEY_PRIVATE_CPP,
    KEY_PUBLIC_CPP,
    PATH,
    _NULL, //-- Other
    HIDE_ITEMS
};

//-- returns the size of a character array using a pointer to the first element of the character array
int size(char *ptr) {
    //variable used to access the subsequent array elements.
    int offset = 0;
    //variable that counts the number of elements in your array
    int count = 0;

    //While loop that tests whether the end of the array has been reached
    while (*(ptr + offset) != '\0') {
        //increment the count variable
        ++count;
        //advance to the next element of the array
        ++offset;
    }
    //return the size of the array
    return count;
}


#endif //DESI_ESP_IMPORTANT_IMPORT_H
